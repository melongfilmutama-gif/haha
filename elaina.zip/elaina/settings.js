// SC ORI SANHUA © DANZ THUMBNAIL
//SC RECODE BY © MANE OFFICIAL
require("./system/module.js")
const { version } = require("./package.json")

global.owner = ['6285748363750']
global.versi = "3.0"
global.storename = "Mane Store"
global.namaOwner = "ManeOfficial"
global.packname = 'Elaina'
global.botname = 'Elaina'
global.youtube = 'https://www.youtube.com/@amaneofc'
global.botnumber = '6285148465940@s.whatsapp.net' 
//☝🏻 ISI PAKE NO BOT KAMU

//thumbnail panel
global.thumbpanel = 'https://files.catbox.moe/ekzdiy.jpg'

//=================================//
//STORE
//👇🏻 ISI INI BUAT FITUR STORE CONTOH NYA DI SINI TINGGAL UBAH UBAH AJA
global.waMe = "wa.me/6285148465940" 
global.linkch = "https://whatsapp.com/channel/0029VbB7WPzAYlUQFsoSwS0d" 
global.chtesti = "https://whatsapp.com/channel/0029VbAu2g6ATRSpePrpSp3L" 

global.dana = '085748363750'
global.qrisdana = 'https://files.catbox.moe/lo22eo.jpg'

global.ovo = 'Tidak Tersedia'
global.qrisovo = 'https://files.catbox.moe/lo22eo.jpg'

global.gopay = 'Tidak Tersedia'
global.qrisgopay = 'https://files.catbox.moe/lo22eo.jpg'

global.qrisallpayment = 'https://files.catbox.moe/lo22eo.jpg'
//===============================//
//DELAY PUSHKONTAK 
global.minDelayPushkontak = 8000;
global.maxDelayPushkontak = 15000;
//===================================//
// SERVER 1
global.domain = '';
// ☝🏻ISI DENGAN LINK DOMAIN PANEL KAMU
global.apikey = ''; 
//☝🏻ISI DENGAN PTLA
global.capikey = ''; 
//☝🏻ISI DENGAN PTLC
global.egg = "15"; 
global.nestid = "5"; 
global.loc = "1";
//================================//

//SERVER 2
global.domainv2 = '';
// ☝🏻ini domain panel kamu
global.apikeyv2 = ''; 
//☝🏻isi dengan ptla ini
global.capikeyv2 = ''; 
//☝🏻isi dengan ptlc
global.eggv2 = "15"; 
global.nestidv2 = "5"; 
global.locv2 = "1";

//SETTING JAM AUTOSHOLAT 
global.jadwalsholat = {
    Subuh: "04:30",
    Dzuhur: "12:00",
    Ashar: "15:15",
    Maghrib: "18:00",
    Isya: "19:15"
};
global.temasholat = "./media/sholat.jpg";


global.systemN = '*sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ*'
global.makeMsg = (text) => {
  return {
    text: `${global.systemN}\n${text}`,
    contextInfo: {
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
        newsletterJid: '120363400297473298@newsletter',
        newsletterName: `${global.botname} by ManeOfficial`,
        serverMessageId: 100
      },
      externalAdReply: { 
        title: '𝙀𝙇𝘼𝙄𝙉𝘼',
        body: 'Elaina asisten',
        thumbnailUrl: 'https://files.catbox.moe/wvooxl.jpg',
        mediaType: 1,
        renderLargerThumbnail: false,
        showAdAttribution: false
      }
    }
  }
}



global.mess = {
  wait: '⏳ Tunggu sebentar... sedang diproses.',
  success: '✅ Berhasil!',
  error: 'Ups! Terjadi kesalahan sistem.',
  errorF: 'Fitur ini sedang dalam perbaikan.',
  group: 'Perintah ini hanya dapat digunakan di grup.',
  private: 'Perintah ini hanya dapat digunakan di chat pribadi.',
  admin: 'Perintah ini hanya untuk admin grup.',
  ress: 'Perintah ini khusus untuk premium',
  owner: 'Perintah ini khusus untuk Owner.',
  botAdmin: 'Jadikan bot sebagai admin dulu ya.'
};

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})