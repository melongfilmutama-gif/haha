// SC ORI SANHUA © DANZ THUMBNAIL
//SC RECODE BY © MANE OFFICIAL
const fs = require('fs');
const path = require('path');

const settingsFilePath = path.join(__dirname, '..', 'settings.json');

const defaultSettings = {
    isPublic: true,
    mutedGroups: []
};

const loadSettings = () => {
    try {
        if (fs.existsSync(settingsFilePath)) {
            const data = fs.readFileSync(settingsFilePath, 'utf8');
            return { ...defaultSettings, ...JSON.parse(data) };
        }
    } catch (error) {
        console.error('Gagal memuat settings.json:', error);
    }
    return defaultSettings;
};

const saveSettings = (data) => {
    try {
        fs.writeFileSync(settingsFilePath, JSON.stringify(data, null, 2));
        console.log(chalk.green('Settings saved'));
    } catch (error) {
        console.error(chalk.red('Gagal save settings:'), error);
    }
};

module.exports = { loadSettings, saveSettings };