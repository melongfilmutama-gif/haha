// SC ORI SANHUA © DANZ THUMBNAIL
//SC RECODE BY © MANE OFFICIAL
// JANGAN HAPUS WM BANG HARGAI YANG BUAT SC
const crypto = require("crypto");
const fs = require('fs');
const axios = require('axios');
const { parseStringPromise } = require('xml2js')
const util = require('util');
const { exec } = require('child_process');
const chalk = require('chalk');
const jimp = require('jimp')
const { GoogleGenerativeAI } = require("@google/generative-ai");
const path = require('path');
const { Sticker, StickerTypes } = require('wa-sticker-formatter');    
const { loadMutedGroups, saveMutedGroups } = require('./system/mutedGroups');

const { prepareWAMessageMedia, generateWAMessageFromContent } = require('@yupra/baileys');
const { saveSettings } = require('./system/sistem.js');

const prayerReminderFilePath = './prayerReminderGroups.json';

const loadPrayerReminderGroups = () => {
    try {
        if (fs.existsSync(prayerReminderFilePath)) {
            const data = fs.readFileSync(prayerReminderFilePath, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Gagal memuat prayerReminderGroups.json:', error);
    }
    return [];
};

const savePrayerReminderGroups = (data) => {
    try {
        fs.writeFileSync(prayerReminderFilePath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Gagal menyimpan prayerReminderGroups.json:', error);
    }
};

if (!global.lastSent) global.lastSent = {};
if (!global.prayerReminderGroups) global.prayerReminderGroups = loadPrayerReminderGroups();

function startPrayerReminder(mane) {
    setInterval(async () => {
        const moment = require('moment-timezone');
        const now = moment().tz("Asia/Jakarta").format("HH:mm");
        const today = moment().tz("Asia/Jakarta").format("YYYY-MM-DD");

        for (const groupId of global.prayerReminderGroups) {
            for (let [nama, waktu] of Object.entries(global.jadwalsholat)) {
                const key = `${groupId}-${nama}-${today}`;

                if (now === waktu) {
                    if (!global.lastSent[key] || (global.lastSent[key] && Date.now() - global.lastSent[key] > 60000)) {
                        try {
                            const audioUrl = "https://files.catbox.moe/lq69y0.m4a";
                            let thumbnailBuffer = null;

                            if (fs.existsSync(global.temasholat)) {
                                const image = await jimp.read(global.temasholat);
                                image.cover(256, 256).quality(85);
                                thumbnailBuffer = await image.getBufferAsync(jimp.MIME_JPEG);
                            }

                            await mane.sendMessage(groupId, {
                                audio: { url: audioUrl },
                                mimetype: "audio/mp4",
                                ptt: false,
                                contextInfo: {
                                    externalAdReply: {
                                        title: `⏰ Waktu Sholat ${nama}`,
                                        body: "Mari kita laksanakan sholat tepat waktu 🕌",
                                        thumbnail: thumbnailBuffer,
                                        mediaType: 1,
                                        renderLargerThumbnail: true
                                    }
                                }
                            });

                            console.log(chalk.green(`✅ Pengingat sholat ${nama} terkirim ke grup ${groupId}`));
                            global.lastSent[key] = Date.now();
                            
                        } catch (e) {
                            console.error(chalk.red("❌ Gagal kirim pengingat:"), e);
                        }
                    }
                }
            }
        }
        
        const oneDayAgo = Date.now() - 86400000;
        for (const key in global.lastSent) {
            if (global.lastSent[key] < oneDayAgo) {
                delete global.lastSent[key];
            }
        }
        
    }, 30000);
}




const premiumUsersFilePath = './premiumUsers.json';
const premiumUsersV2FilePath = './premiumUsersV2.json';

const loadPremiumUsers = (filePath) => {
    try {
        if (fs.existsSync(filePath)) {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error(`Gagal memuat file premium ${filePath}:`, error);
    }
    return [];
};

const savePremiumUsers = (data, filePath) => {
    try {
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error(`Gagal menyimpan file premium ${filePath}:`, error);
    }
};

global.premiumusers = loadPremiumUsers(premiumUsersFilePath);
global.premiumusersv2 = loadPremiumUsers(premiumUsersV2FilePath);

const resellerV2FilePath = './resellerV2.json';
const loadResellerGroupsV2 = () => {
    try {
        if (fs.existsSync(resellerV2FilePath)) {
            const data = fs.readFileSync(resellerV2FilePath, 'utf8');
            const parsedData = JSON.parse(data);
            return Array.isArray(parsedData) ? parsedData : [];
        }
    } catch (error) {
        console.error('Gagal memuat resellerV2.json:', error);
    }
    return [];
};
    
const saveResellerGroupsV2 = (data) => {
    try {
        fs.writeFileSync(resellerV2FilePath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Gagal menyimpan resellerV2.json:', error);
    }
};

global.resellergroupsv2 = loadResellerGroupsV2();

const resellerFilePath = './reseller.json';

const loadResellerGroups = () => {
    try {
        if (fs.existsSync(resellerFilePath)) {
            const data = fs.readFileSync(resellerFilePath, 'utf8');
            const parsedData = JSON.parse(data);
            return Array.isArray(parsedData) ? parsedData : [];
        }
    } catch (error) {
        console.error('Gagal memuat reseller.json:', error);
    }
    return [];
};


    
const saveResellerGroups = (data) => {
    try {
        fs.writeFileSync(resellerFilePath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Gagal menyimpan reseller.json:', error);
    }
};

global.resellergroups = loadResellerGroups();

const Styles = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  xStr.map((v, i) =>
    replacer.push({
      original: v,
      convert: yStr[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};

async function saveOwnerToSettingsFile() {
  const settingsPath = './settings.js';
  try {
    let fileContent = fs.readFileSync(settingsPath, 'utf8');
    const ownerArrayString = `['${global.owner.join("','")}']`;
    const newOwnerLine = `global.owner = ${ownerArrayString}`;

    const regex = /global\.owner\s*=\s*\[.*\]/g;
    
    if (regex.test(fileContent)) {
      fileContent = fileContent.replace(regex, newOwnerLine);
    } else {
      console.log("Baris 'global.owner' tidak ditemukan di settings.js, tidak dapat menyimpan.");
      return;
    }

    fs.writeFileSync(settingsPath, fileContent, 'utf8');
    console.log(chalk.green('✅ Berhasil menyimpan daftar owner baru ke settings.js'));
  } catch (error) {
    console.error(chalk.red('❌ Gagal menyimpan owner ke settings.js:', error));
  }
}




async function updateApiKeys(updates) {
  const settingsPath = './settings.js';
  try {
    let fileContent = fs.readFileSync(settingsPath, 'utf8');
    updates.forEach(update => {
      const regex = new RegExp(`(global\\.${update.key}\\s*=\\s*)['"].*?['"]`);
      if (regex.test(fileContent)) {
        fileContent = fileContent.replace(regex, `$1'${update.value}'`);
      }
    });
    fs.writeFileSync(settingsPath, fileContent, 'utf8');
    return true;
  } catch (error) {
    console.error(chalk.red('❌ Gagal menyimpan API Key ke settings.js:', error));
    return false;
  }
}

function getVideoResolution(videoPath) {

    return new Promise((resolve, reject) => {

        const ffprobeCommand = `ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 "${videoPath}"`;

        exec(ffprobeCommand, (err, stdout, stderr) => {

            if (err) {

                return reject(new Error(`Gagal mendapatkan resolusi video: ${stderr || err.message}`));

            }

            if (!stdout) {

                return reject(new Error('Tidak dapat membaca output resolusi video.'));

            }

            const [width, height] = stdout.trim().split('x').map(Number);

            resolve({ width, height });

        });

    });

}

function getVideoResolution(videoPath) {
    const { exec } = require('child_process');
    return new Promise((resolve, reject) => {
        const ffprobeCommand = `ffprobe -v error -select_streams v:0 -show_entries stream=width,height -of csv=s=x:p=0 "${videoPath}"`;
        exec(ffprobeCommand, (err, stdout, stderr) => {
            if (err) {
                return reject(new Error(`Gagal mendapatkan resolusi video. Pastikan ffmpeg terpasang. Error: ${stderr || err.message}`));
            }
            if (!stdout) {
                return reject(new Error('Tidak dapat membaca output resolusi video.'));
            }
            const [width, height] = stdout.trim().split('x').map(Number);
            resolve({ width, height });
        });
    });
}






module.exports = async (mane, m, store) => {
if (!global.prayerReminderStarted) {
        startPrayerReminder(mane);
        global.prayerReminderStarted = true;
    }
try {

const sender = (m.key?.fromMe)
  ? (mane.user.id.split(':')[0] + '@s.whatsapp.net')
  : (m.key?.participant || m.key?.remoteJid || '');
    const senderNumber = m.sender.split('@')[0];
    const chatType = m.isGroup ? 'GROUP' : 'PRIVATE';
    
    const isOwner = global.owner.includes(senderNumber) || m.sender === global.botnumber;
    const isCreator = m.sender === global.botnumber;
    

    if (!mane.public && !isOwner) {
        console.log(chalk.gray(`[MODE SELF] Pesan dari ${m.pushName || senderNumber} diabaikan`));
        return;
    }

    console.log(chalk.cyan(`[${chatType}] Dari: ${m.pushName || senderNumber} | Pesan: ${m.text || '(media)'}`));

    const reply = async (message) => {
        await mane.sendMessage(m.chat, global.makeMsg(message), { quoted: m });
    };
    m.reply = reply;
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ""
	
const budy = (typeof m.text == 'string' ? m.text : '') 

const from = m.key.remoteJid
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
function isCommandExistInCode(cmd) {
  const fs = require('fs');
  const source = fs.readFileSync(__filename, 'utf8');
  const regex = new RegExp(`case ['"\`]${cmd}['"\`]`, 'i');
  return regex.test(source);
}
if (isCmd && isCommandExistInCode(command)) {
  await mane.sendPresenceUpdate('composing', m.chat);
  setTimeout(() => mane.sendPresenceUpdate('paused', m.chat), 5000); 
}


const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const botNumber = await mane.decodeJid(mane.user.id)
const pushname = m.pushName || `${m.sender.split("@")[0]}`
const { runtime, isUrl, getRandom, getTime, tanggal, toRupiah, telegraPh, pinterest, toHD, ucapan, generateProfilePicture, formatp, getBuffer, fetchJson, resize, sleep } = require('./system/function.js')


m.isGroup = m.chat.endsWith("g.us");

if (m.isGroup) {
    m.metadata = store.groupMetadata[m.chat] || await mane.groupMetadata(m.chat).catch(_ => null) || {};
    
    if (m.metadata.id && !store.groupMetadata[m.chat]) {
        store.groupMetadata[m.chat] = m.metadata;
    }
    
    const participants = m.metadata.participants || [];
    
    m.isAdmin = !!participants.find(p => p.jid.split('@')[0] === m.sender.split('@')[0])?.admin;
    m.isBotAdmin = !!participants.find(p => p.jid.split('@')[0] === botNumber.split('@')[0])?.admin;

} else {
    m.metadata = {};
    m.isAdmin = false;
    m.isBotAdmin = false;
}

const senderId = m.sender.split('@')[0];
const isPremium = global.premiumusers.includes(senderId);
const isPremiumV2 = global.premiumusersv2.includes(senderId);
const isResellerV2 = m.isGroup && global.resellergroupsv2.includes(m.chat);
const isReseller = m.isGroup && global.resellergroups.includes(m.chat);

if (body) {
    console.log(chalk.yellow.bgCyan.bold(global.botname || 'BOT'), 
        chalk.blue.bold(isCmd ? '[ COMMAND ]' : '[ CHAT ]'), 
        chalk.blue.bold('DARI'), chalk.blue.bold(`${pushname}`), 
        chalk.blue.bold('Isi Pesan :'), chalk.blue.bold(`${body}`)
    );
}


function capitalize(word) {
  return word.charAt(0).toUpperCase() + word.slice(1);
}

if (m.isGroup && global.mutedGroups.includes(m.chat) && !isOwner) {
    console.log(chalk.gray(`[MUTED] Pesan dari ${m.chat} diabaikan (grup dimute)`));
    return;
}

if ((budy.match) && ["mane", "mane",].includes(budy) && !isCmd) {

await reply('ELAINA ONLINE😃')

}    

const thumbnailPath = './media/fq.jpg';
let thumbnailBuffer = null;

if (fs.existsSync(thumbnailPath)) {
    const image = await jimp.read(thumbnailPath);
    
    image.cover(256, 256)
         .quality(85);
         
    thumbnailBuffer = await image.getBufferAsync(jimp.MIME_JPEG);
}

const fakeStatus = {
    key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(m.chat ? { remoteJid: "status@broadcast" } : {})
    },
    message: {
        imageMessage: {
            mimetype: "image/jpeg",
            caption: "ELAINA BOT BY MANE",
            jpegThumbnail: thumbnailBuffer
        }
    }
};
const pushkontakFakeReply = {
    key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        remoteJid: "status@broadcast"
    },
    message: {
        contactMessage: {
            displayName: `${global.botname}`,
            vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${global.namaOwner};;;\nFN:${global.namaOwner}\nitem1.TEL;waid=${global.owner[0]}:${global.owner[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
        }
    }
};
    
switch (command) {
case "menu": {
    await mane.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
    const moment = require('moment-timezone');
    const jimp = require('jimp');

    moment.tz.setDefault('Asia/Jakarta');
    const jam = moment().format('HH:mm');
    const hari = moment().format('dddd, D MMMM YYYY');

    const image = await jimp.read("./media/menu.jpg");
    if (image.bitmap.width > image.bitmap.height) {
        image.resize(300, jimp.AUTO);
    } else {
        image.resize(jimp.AUTO, 300);
    }
    image.quality(90);
    const thumbnail = await image.getBufferAsync(jimp.MIME_JPEG);

    const menuText = `
╭───☢︎ *Informasi Bot*
│ ◈ Nama-Bot : ${global.botname}
│ ◈ Devoloper : ${global.namaOwner}
│ ◈ Mode : ${mane.public ? '🌐 Public' : '🔒 Self'}
│ ◈ Version : ${global.versi}
│ ◈ date : ${hari}, pukul ${jam}
│ ◈ Runtime : ${runtime(process.uptime())}
│ ◈ YouTube : ${global.youtube}
╰──────────────────⪨

*KATA KATA*
*幸福は外からではなく、自分自身の内側から生まれます。*

`;
    await mane.sendMessage(m.chat, {
        footer: `© ELAINA`,
        buttons: [
            { buttonId: '.allmenu', buttonText: { displayText: 'ALLMENU' }, type: 1 },
            { buttonId: '.owner', buttonText: { displayText: 'OWNER👑' }, type: 1 },
            { buttonId: '.tqto', buttonText: { displayText: 'TQTO💝' }, type: 1 }, 
            { buttonId: '.menu', buttonText: { displayText: 'MENU🕊' }, type: 1 }
        ],
        headerType: 1,
        document: fs.readFileSync("./package.json"),
        fileName: `elaina - mane`,
        mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        fileLength: 9999999999,
        caption: menuText,
        contextInfo: {
            isForwarded: true,
            externalAdReply: {
                title: `ELAINA - ${global.versi}`,
                body: `Powered by ${global.namaOwner}`,
                thumbnail,
                mediaType: 1,
                renderLargerThumbnail: true,
            },
        },
    }, { quoted: fakeStatus });
}
break;
case 'allmenu': {
    await mane.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
    const fs = require('fs');
    const moment = require('moment-timezone');
    const jimp = require('jimp');

    const videoPath = './media/menu.mp4';
    const thumbnailPath = './media/menu.jpg';

    if (!fs.existsSync(videoPath)) {
        return m.reply("Gagal menampilkan menu: File video './media/menu.mp4' tidak dapat ditemukan di server.");
    }
    if (!fs.existsSync(thumbnailPath)) {
        return m.reply("Gagal menampilkan menu: File thumbnail './media/menu.jpg' tidak dapat ditemukan di server.");
    }

    try {
        const videoBuffer = fs.readFileSync(videoPath);
        
        const image = await jimp.read(thumbnailPath);
        if (image.bitmap.width > image.bitmap.height) {
            image.resize(300, jimp.AUTO);
        } else {
            image.resize(jimp.AUTO, 300);
        }
        image.quality(90);
        const thumbnailBuffer = await image.getBufferAsync(jimp.MIME_JPEG);

        moment.tz.setDefault('Asia/Jakarta');
        const jam = moment().format('HH:mm');
        const hari = moment().format('dddd, D MMMM YYYY');
        const audioUrl = 'https://files.catbox.moe/s3czob.mp3';
        
        const menuCaption = `*Elaina Assistant Active🌐*

Halo👋🏻 *${pushname}*, saya siap membantu.
Berikut beberapa kemampuan saya :

╭───☢︎ *Informasi Bot*
│ ◈ Nama-Bot : ${global.botname}
│ ◈ Devoloper : ${global.namaOwner}
│ ◈ Mode : ${mane.public ? '🌐 Public' : '🔒 Self'}
│ ◈ Version : ${global.versi}
│ ◈ date : ${hari}, pukul ${jam}
│ ◈ Runtime : ${runtime(process.uptime())}
│ ◈ YouTube : ${global.youtube}
╰──────────────────⪨

╔═《 *PANEL SERVER 1 MENU* 》
╠> \`\`\`.listram\`\`\`
╠> \`\`\`.cadmin\`\`\` 
╠> \`\`\`.delpanel\`\`\`
╠> \`\`\`.deladmin\`\`\`
╠> \`\`\`.listpanel\`\`\`
╠> \`\`\`.listadmin\`\`\`

╔═《 *PANEL SERVER 2 MENU* 》
╠> \`\`\`.listramv2\`\`\`
╠> \`\`\`.cadminv2\`\`\`
╠> \`\`\`.delpanelv2\`\`\`
╠> \`\`\`.deladminv2\`\`\`
╠> \`\`\`.listpanelv2\`\`\`
╠> \`\`\`.listadminv2\`\`\`

╔═《 *MENU ISLAMI* 》
╠> \`\`\`.jadwalsholat\`\`\`
╠> \`\`\`.asmaulhusna\`\`\`
╠> \`\`\`.niatsholat\`\`\`
╠> \`\`\`.doa\`\`\`
╠> \`\`\`.sholat on/off (pengingat sholat)\`\`\`

╔═《 *MENU KRISTEN* 》
╠> \`\`\`.alkitab (cari ayat Alkitab, contoh: Yoh 3 16)\`\`\`
╠> .doakristen (doa Kristen sehari-hari)
╠> \`\`\`.renungan (renungan harian singkat)\`\`\`
╠> \`\`\`.jadwalibadah (jadwal ibadah mingguan)\`\`\`


╔═《 *PUSHKONTAK MENU* 》
╠> \`\`\`.pushkontak\`\`\`
╠> \`\`\`.pushkontakv2\`\`\`

╔═《 *RESELLER SERVER 1* 》
╠> \`\`\`.addakses (add akses grub reseller panel)\`\`\`
╠> \`\`\`.delakses (menghapus akses grub reseller panel)\`\`\`
╠> \`\`\`.addpremium (add akses create panel+adp)\`\`\`

╔═《 *RESELLER SERVER 2* 》
╠> \`\`\`.addaksesv2 (add akses grub reseller panel)\`\`\`
╠> \`\`\`.delaksesv2 (menghapus akses grub reseller panel)\`\`\`
╠> \`\`\`.addpremiumv2 (add akses create panel+adp)\`\`\`

╔═《 *OWNER MENU* 》
╠> \`\`\`.tqto\`\`\`  
╠> \`\`\`.autoread\`\`\`  
╠> \`\`\`.delowner\`\`\`  
╠> \`\`\`.addowner\`\`\`  
╠> \`\`\`.jpm\`\`\`
╠> \`\`\`.listjpmgc\`\`\`
╠> \`\`\`.self\`\`\`
╠> \`\`\`.public\`\`\`
╠> \`\`\`.mute\`\`\`
╠> \`\`\`.unmute\`\`\`
╠> \`\`\`.owner\`\`\`
╠> \`\`\`.upapikey\`\`\`
╠> \`\`\`.upapikey2\`\`\`
╠> \`\`\`.delapikey\`\`\`
╠> \`\`\`.delapikey2\`\`\`

╔═《 *IMAGE*》
╠> \`\`\`.hd\`\`\` 
╠> \`\`\`.remini\`\`\` 
╠> \`\`\`.botakin\`\`\` 
╠> \`\`\`.winkvideo\`\`\` 
╠> \`\`\`.hitamkan\`\`\` 
╠> \`\`\`.iqc\`\`\` 

╔═《 *STORE MENU* 》
╠> \`\`\`.qris\`\`\` 
╠> \`\`\`.dana\`\`\` 
╠> \`\`\`.ovo\`\`\` 
╠> \`\`\`.gopay\`\`\` 
╠> \`\`\`.proses\`\`\` 
╠> \`\`\`.done\`\`\` 

╔═《 *STICKER MENU* 》
╠> \`\`\`.brat\`\`\` 
╠> \`\`\`.bratvid\`\`\` 
╠> \`\`\`.qc\`\`\` 
╠> \`\`\`.s\`\`\` 
╠> \`\`\`.smeme\`\`\` 
╠> \`\`\`.rvo\`\`\` 

╔═《 *CONVERT*》
╠> \`\`\`.tourl\`\`\` 

╔═《 *GROUP MENU*》
╠> \`\`\`.hidetag\`\`\` 
╠> \`\`\`.add\`\`\` 
╠> \`\`\`.kick\`\`\` 

╔═《 *PLAY DOWNLOAD* 》
╠> \`\`\`.play \`\`\`
╠> \`\`\`.tiktok\`\`\` 

╔═《 *CEK ID CH/GC* 》
╠> \`\`\`.cekidch\`\`\` 
╠> \`\`\`.cekidgc\`\`\`

*— ELAINA, evolving assistant built by Mane.*`;

        await mane.sendMessage(m.chat, {
            video: videoBuffer, 
            gifPlayback: true,
            caption: menuCaption,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: `${global.namaOwner}`,
                    newsletterJid: `120363400297473298@newsletter`,
                },
                externalAdReply: {
                    title: global.botname,
                    body: global.namaOwner,
                    thumbnail: thumbnailBuffer,
                    sourceUrl: ``,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    mentionedJid: [m.sender]
                }
            }
        }, { quoted: fakeStatus });

        const audioMessage = {
            audio: { url: audioUrl },
            mimetype: 'audio/mp4',
            ptt: true,
        };
        await mane.sendMessage(m.chat, audioMessage, { quoted: m });

    } catch (error) {
        console.error("Error saat mengirim menu 'allmenumane':", error);
        await m.reply(`Terjadi kesalahan teknis saat menampilkan menu. Silakan cek log/konsol untuk detail error: ${error.message}`);
    }
}
break;
case "1gb":
case "2gb":
case "3gb":
case "4gb":
case "5gb":
case "6gb":
case "7gb":
case "8gb":
case "9gb":
case "10gb":
case "unli":
case "unlimited": {
    const missingSettings = [];
    if (!global.domain) missingSettings.push("`global.domain`");
    if (!global.apikey) missingSettings.push("`global.apikey` (ptla)");
    if (!global.capikey) missingSettings.push("`global.capikey` (ptlc)");

    if (missingSettings.length > 0) {
        return m.reply(`⚠️ *Konfigurasi Server 1 Belum Lengkap!*\nHarap isi variabel berikut di \`settings.js\`:\n\n${missingSettings.join('\n')}`);
    }

    if (!isOwner && !isReseller && !isPremium) {
        return m.reply("Perintah ini hanya bisa diakses oleh Owner, Premium, atau anggota grup Reseller.");
    }
    
    let nomor;
    let usernem;

    if (m.quoted) {
        nomor = m.quoted.sender;
        usernem = text.split(',')[0].trim().toLowerCase();
    } else if (text.includes(",")) {
        if (!isOwner) return m.reply("Hanya Owner yang dapat membuat panel untuk nomor lain.");
        const [users, nom] = text.split(",");
        if (!users || !nom) return m.reply(`Format salah. Contoh:\n.${command} username,628xxxx`);
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.trim().toLowerCase();
    } else {
        nomor = m.sender;
        usernem = text.trim().toLowerCase();
    }

    if (!usernem) return m.reply(`Username tidak boleh kosong!\n\nContoh Penggunaan:\n1. Reply pesan: \`.${command} username\`\n2. Ketik nomor: \`.${command} username,628xxx\`\n3. Untuk diri sendiri: \`.${command} username\``);

    const [onWa] = await mane.onWhatsApp(nomor.split("@")[0]);
    if (!onWa?.exists) return m.reply("❌ Nomor target tidak terdaftar di WhatsApp!");

    const paket = {
        "1gb": { ram: "1000", disk: "1000", cpu: "40" }, "2gb": { ram: "2000", disk: "1000", cpu: "60" },
        "3gb": { ram: "3000", disk: "2000", cpu: "80" }, "4gb": { ram: "4000", disk: "2000", cpu: "100" },
        "5gb": { ram: "5000", disk: "3000", cpu: "120" }, "6gb": { ram: "6000", disk: "3000", cpu: "140" },
        "7gb": { ram: "7000", disk: "4000", cpu: "160" }, "8gb": { ram: "8000", disk: "4000", cpu: "180" },
        "9gb": { ram: "9000", disk: "5000", cpu: "200" }, "10gb": { ram: "10000", disk: "5000", cpu: "220" },
        "unli": { ram: "0", disk: "0", cpu: "0" }, "unlimited": { ram: "0", disk: "0", cpu: "0" }
    };

    const specs = paket[command];
    if (!specs) return m.reply("❌ Paket tidak valid.");
    const { ram, disk: disknya, cpu } = specs;
    const password = usernem + crypto.randomBytes(3).toString("hex");

    try {
        await m.reply(`⏳ Memproses pembuatan panel untuk *${usernem}*...`);

        const userPayload = {
            email: `${usernem}@gmail.com`, username: usernem,
            first_name: capitalize(usernem), last_name: "Elaina",
            language: "en", password
        };
        const userResponse = await axios.post(`${global.domain}/api/application/users`, userPayload, {
            headers: { Authorization: `Bearer ${global.apikey}`, "Content-Type": "application/json", Accept: "application/json" }
        });
        
        const user = userResponse.data.attributes;
        
        const eggData = await axios.get(`${global.domain}/api/application/nests/${global.nestid}/eggs/${global.egg}`, {
            headers: { Authorization: `Bearer ${global.apikey}` }
        });
        
        const serverPayload = {
            name: `${capitalize(usernem)} Elaina`, user: user.id, egg: parseInt(global.egg),
            docker_image: eggData.data.attributes.docker_image, startup: eggData.data.attributes.startup,
            environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
            limits: { memory: ram, swap: 0, disk: disknya, io: 500, cpu },
            feature_limits: { databases: 5, backups: 5, allocations: 5 },
            deploy: { locations: [parseInt(global.loc)], dedicated_ip: false, port_range: [] }
        };
        const serverResponse = await axios.post(`${global.domain}/api/application/servers`, serverPayload, {
            headers: { Authorization: `Bearer ${global.apikey}`, "Content-Type": "application/json", Accept: "application/json" }
        });

        const detailTeks = `*✅ Panel Berhasil Dibuat!*

👤 *Username:* \`${user.username}\`
🔐 *Password:* \`${password}\`
🌐 *Login:* ${global.domain}

🧠 *Spesifikasi Server:*
• RAM: ${ram === "0" ? "Unlimited" : `${parseInt(ram) / 1000} GB`}
• Disk: ${disknya === "0" ? "Unlimited" : `${parseInt(disknya) / 1000} GB`}
• CPU: ${cpu === "0" ? "Unlimited" : `${cpu}%`}

📝 *Catatan:* Simpan detail ini baik-baik. Masa aktif 30 hari.`;

        try {
            const preparedImage = await prepareWAMessageMedia({ image: { url: global.thumbpanel } }, { upload: mane.waUploadToServer });
            const interactiveMessage = {
                body: { text: detailTeks }, footer: { text: '© ELAINA PANEL' },
                header: { title: "🎉 Akun Anda Siap Digunakan!", hasMediaAttachment: true, imageMessage: preparedImage.imageMessage },
                nativeFlowMessage: {
                    buttons: [
                        { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "COPY USERNAME", copy_code: user.username }) },
                        { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "COPY PASSWORD", copy_code: password }) }
                    ]
                }
            };
            const msg = generateWAMessageFromContent(nomor, { viewOnceMessage: { message: { interactiveMessage } } }, { userJid: nomor });
            await mane.relayMessage(nomor, msg.message, { messageId: msg.key.id });
        } catch (sendErr) {
            console.error("Gagal mengirim pesan interaktif, mengirim sebagai teks biasa. Error:", sendErr);
            await mane.sendMessage(nomor, { text: detailTeks });
        }

        await mane.sendMessage(m.chat, {
            text: `✅ Selesai! Detail panel telah dikirim ke @${nomor.split('@')[0]}.`,
            mentions: [nomor]
        }, { quoted: m });

    } catch (err) {
        console.error("Gagal membuat panel Server 1:", util.inspect(err, false, null, true));
        const e = err?.response?.data?.errors?.[0]?.detail || err.message;
        return m.reply(`❌ Gagal membuat panel.\n*Pesan Error:* ${e}`);
    }
}
break;
case "cadmin": {
    const missingSettings = [];
    if (!global.domain) missingSettings.push("`global.domain`");
    if (!global.apikey) missingSettings.push("`global.apikey` (ptla)");

    if (missingSettings.length > 0) {
        return m.reply(`⚠️ *Konfigurasi Server 1 Belum Lengkap!*\nHarap isi variabel berikut di \`settings.js\`:\n\n${missingSettings.join('\n')}`);
    }

    if (!isOwner && !isPremium) return m.reply(mess.ress);
    
    let nomor;
    let usernem;

    // Logika baru untuk menentukan target
    if (m.quoted) {
        nomor = m.quoted.sender;
        usernem = text.split(',')[0].trim().toLowerCase();
    } else if (text.includes(",")) {
        if (!isOwner) return m.reply("Hanya Owner yang dapat membuat akun admin untuk nomor lain.");
        const [users, nom] = text.split(",");
        if (!users || !nom) return m.reply(`Format salah. Contoh:\n.cadmin username,628xxxx`);
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.trim().toLowerCase();
    } else {
        nomor = m.sender;
        usernem = text.trim().toLowerCase();
    }

    if (!usernem) return m.reply(`Username tidak boleh kosong!\n\nContoh:\n.cadmin namauser`);

    const [onWa] = await mane.onWhatsApp(nomor.split("@")[0]);
    if (!onWa?.exists) return m.reply("Nomor target tidak terdaftar di WhatsApp!");

    let password = usernem + crypto.randomBytes(2).toString('hex');
    
    try {
        await m.reply(`⏳ Memproses pembuatan akun admin untuk *${usernem}*...`);

        const userPayload = {
            email: `${usernem}@gmail.com`,
            username: usernem,
            first_name: capitalize(usernem), last_name: "Admin",
            root_admin: true, language: "en", password
        };
        const userResponse = await axios.post(`${global.domain}/api/application/users`, userPayload, {
            headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikey}` }
        });

        const user = userResponse.data.attributes;

        const detailTeks = `*✅ Akun Admin Panel Anda Telah Siap!*

👤 *Username:* \`${user.username}\`
🔐 *Password:* \`${password}\`
🌐 *Login:* ${global.domain}

*Penting:* Akun ini memiliki akses penuh. Gunakan dengan bijak.`;
        
        try {
            const preparedImage = await prepareWAMessageMedia({ image: { url: global.thumbpanel } }, { upload: mane.waUploadToServer });
            const interactiveMessage = {
                body: { text: detailTeks }, footer: { text: '© ELAINA PANEL' },
                header: { title: "✅ Akun Admin Siap!", hasMediaAttachment: true, imageMessage: preparedImage.imageMessage },
                nativeFlowMessage: {
                    buttons: [
                        { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "COPY USERNAME", copy_code: user.username }) },
                        { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "COPY PASSWORD", copy_code: password }) }
                    ]
                }
            };
            const msg = generateWAMessageFromContent(nomor, { viewOnceMessage: { message: { interactiveMessage } } }, { userJid: nomor });
            await mane.relayMessage(nomor, msg.message, { messageId: msg.key.id });
        } catch (sendErr) {
            console.error("Gagal mengirim pesan interaktif, mengirim sebagai teks biasa. Error:", sendErr);
            await mane.sendMessage(nomor, { text: detailTeks });
        }

        if (nomor !== m.sender) {
            await mane.sendMessage(m.chat, {
                text: `✅ Selesai! Detail admin telah dikirim ke @${nomor.split('@')[0]}.`,
                mentions: [nomor]
            }, { quoted: m });
        } else {
            await m.reply(`✅ Selesai! Detail admin telah dikirim ke chat pribadi Anda.`);
        }

    } catch (err) {
        console.error("Gagal membuat admin Server 1:", util.inspect(err, false, null, true));
        const e = err?.response?.data?.errors?.[0]?.detail || err.message;
        return m.reply(`❌ Gagal membuat admin.\n*Pesan Error:* ${e}`);
    }
}
break;
case 'delpanel': {
    if (!isOwner) return m.reply(mess.owner);

    if (args[0]) {
        const serverId = args[0];
        if (isNaN(serverId)) return m.reply("ID Server harus berupa angka.");

        try {
            const serverDetailsResponse = await axios.get(`${global.domain}/api/application/servers/${serverId}`, {
                headers: { "Authorization": "Bearer " + global.apikey }
            });
            const serverDetails = serverDetailsResponse.data.attributes;
            const serverName = serverDetails.name;
            const userId = serverDetails.user;

            const userDetailsResponse = await axios.get(`${global.domain}/api/application/users/${userId}`, {
                headers: { "Authorization": "Bearer " + global.apikey }
            });
            const isUserAdmin = userDetailsResponse.data.attributes.root_admin;

            let buttons = [];

            if (!isUserAdmin) {
                buttons.unshift({
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Hapus Panel + User",
                        id: `${prefix}delpanel_user_and_panel ${serverId}`
                    })
                });
            }

            buttons.push({
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "Hapus Panel Saja",
                    id: `${prefix}delpanel_only ${serverId}`
                })
            });

            const interactiveMessage = {
                body: { text: `Anda telah memilih server:\n\n*Nama:* ${serverName}\n*ID:* ${serverId}\n*Status User:* ${isUserAdmin ? 'Admin' : 'Bukan Admin'}` },
                footer: { text: 'Tindakan ini tidak dapat diurungkan!' },
                header: { title: "KONFIRMASI PENGHAPUSAN", hasMediaAttachment: false },
                nativeFlowMessage: {
                    buttons: buttons
                }
            };

            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                        interactiveMessage: interactiveMessage
                    }
                }
            }, { quoted: m });

            await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        } catch (error) {
            m.reply("Gagal mendapatkan detail server. Pastikan ID Server benar.");
        }

    } else {
        try {
            await m.reply("proses..... jika tidak muncul berarti anda pakai wa bussines anda bisa pakai .listpanel trus ketik .delpanel angka sesuai di list");

            const serverListResponse = await axios.get(`${global.domain}/api/application/servers`, {
                headers: {
                    "Accept": "application/json",
                    "Authorization": "Bearer " + global.apikey
                }
            });

            const servers = serverListResponse.data.data;
            if (!servers || servers.length === 0) {
                return m.reply("Tidak ada server yang ditemukan di panel.");
            }

            const serverRows = servers.map(server => ({
                title: server.attributes.name,
                description: `ID: ${server.attributes.id} | RAM: ${server.attributes.limits.memory} MB`,
                id: `${prefix}delpanel ${server.attributes.id}` 
            }));
            
            const paramsJson = {
                title: 'Pilih Server Untuk Dihapus',
                sections: [{
                    title: 'DAFTAR SERVER PANEL',
                    highlight_label: `${servers.length} Server Tersedia`,
                    rows: serverRows
                }]
            };

            
            const interactiveMessage = {
                body: { text: "Silakan pilih server yang ingin Anda hapus." },
                footer: { text: "Manajemen Panel © ELAINA BY MANE" },
                header: { title: "PILIH SERVER", hasMediaAttachment: false },
                nativeFlowMessage: {
                    buttons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify(paramsJson)
                    }]
                }
            };
    
            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                        interactiveMessage: interactiveMessage
                    }
                }
            }, { quoted: m });
    
            await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        } catch (error) {
            m.reply(`Terjadi Kesalahan:\n${error.message}`);
        }
    }
}
break;
case 'listpanel': {
    if (!isOwner) return m.reply(mess.owner);
    
    try {
        await m.reply("⏳ Mengambil daftar server dan user, mohon tunggu...");
        
        const serverListResponse = await axios.get(`${global.domain}/api/application/servers`, {
            headers: { "Authorization": "Bearer " + global.apikey }
        });

        const servers = serverListResponse.data.data;
        if (!servers || servers.length === 0) {
            return m.reply("Tidak ada server yang ditemukan di panel.");
        }

        let listText = "*DAFTAR SEMUA PANEL & USER*\n";
        for (const server of servers) {
            try {
                const userDetails = await axios.get(`${global.domain}/api/application/users/${server.attributes.user}`, {
                    headers: { "Authorization": "Bearer " + global.apikey }
                });
                const username = userDetails.data.attributes.username;
                const isAdmin = userDetails.data.attributes.root_admin;
                listText += `\n─────────────────\n`;
                listText += `*Server:* ${server.attributes.name}\n`;
                listText += `*ID Server:* ${server.attributes.id}\n`;
                listText += `*User:* ${username} ${isAdmin ? '*(Admin)*' : ''}`;
            } catch (userError) {
                listText += `\n─────────────────\n`;
                listText += `*Server:* ${server.attributes.name}\n`;
                listText += `*ID Server:* ${server.attributes.id}\n`;
                listText += `*User:* (Gagal mengambil data)`;
            }
        }
        
        m.reply(listText.trim());

    } catch (error) {
        m.reply(`Terjadi Kesalahan:\n${error.message}`);
    }
}
break;

case 'delpanel_only': {
    if (!isOwner) return m.reply(mess.owner);
    const serverId = args[0];
    if (!serverId || isNaN(serverId)) return m.reply("ID Server tidak valid.");

    try {
        await m.reply(`Menghapus server dengan ID ${serverId}...`);
        await axios.delete(`${global.domain}/api/application/servers/${serverId}?force=true`, {
            headers: { "Authorization": "Bearer " + global.apikey }
        });
        m.reply(`✅ Sukses menghapus server dengan ID *${serverId}*.\n\nCatatan: User yang terkait tidak ikut terhapus.`);
    } catch (error) {
        const errorMsg = error.response ? `Gagal menghapus server. Status: ${error.response.status}.` : error.message;
        return m.reply(`Terjadi Kesalahan:\n${errorMsg}\n\nPastikan ID Server benar.`);
    }
}
break;

case 'delpanel_user_and_panel': {
    if (!isOwner) return m.reply(mess.owner);
    const serverId = args[0];
    if (!serverId || isNaN(serverId)) return m.reply("ID Server tidak valid.");

    try {
        await m.reply(`⏳ Memulai proses penghapusan untuk server ID ${serverId}...`);

        const serverDetails = await axios.get(`${global.domain}/api/application/servers/${serverId}`, {
            headers: { "Authorization": "Bearer " + global.apikey }
        });

        const userId = serverDetails.data.attributes.user;
        const serverName = serverDetails.data.attributes.name;

        const userDetails = await axios.get(`${global.domain}/api/application/users/${userId}`, {
            headers: { "Authorization": "Bearer " + global.apikey }
        });
        
        if (userDetails.data.attributes.root_admin) {
            await m.reply(`⚠️ User terkait adalah Admin. Hanya server [${serverName}] yang akan dihapus.`);
            await axios.delete(`${global.domain}/api/application/servers/${serverId}?force=true`, {
                headers: { "Authorization": "Bearer " + global.apikey }
            });
            await m.reply(`✅ Server [${serverName}] berhasil dihapus. User Admin tidak dihapus.`);
        } else {
            await axios.delete(`${global.domain}/api/application/servers/${serverId}?force=true`, {
                headers: { "Authorization": "Bearer " + global.apikey }
            });
            await m.reply(`✅ Server [${serverName}] berhasil dihapus.`);
            
            await axios.delete(`${global.domain}/api/application/users/${userId}`, {
                headers: { "Authorization": "Bearer " + global.apikey }
            });
            await m.reply(`✅ User terkait dengan ID ${userId} juga berhasil dihapus.`);
        }
    } catch (error) {
        let errorMsg = error.response ? `Gagal. Status: ${error.response.status}. Mungkin server atau user sudah dihapus.` : error.message;
        return m.reply(`Terjadi Kesalahan:\n${errorMsg}`);
    }
}
break;
case 'deladmin': {
    if (!isOwner) return m.reply(mess.owner);

    if (args[0]) {
        const userId = args[0];
        if (isNaN(userId)) return m.reply("ID User harus berupa angka.");

        try {
            const userDetailsResponse = await axios.get(`${global.domain}/api/application/users/${userId}`, {
                headers: { "Authorization": "Bearer " + global.apikey }
            });
            const userDetails = userDetailsResponse.data.attributes;

            if (!userDetails.root_admin) {
                return m.reply(`User dengan ID ${userId} bukan seorang admin.`);
            }

            const serverListResponse = await axios.get(`${global.domain}/api/application/servers`, {
                headers: { "Authorization": "Bearer " + global.apikey }
            });
            const allServers = serverListResponse.data.data;
            const adminServers = allServers.filter(server => server.attributes.user == userId);

            if (adminServers.length > 0) {
                let serverListText = `*Gagal!* User admin *${userDetails.username}* tidak bisa dihapus karena masih memiliki server berikut. Anda harus menghapus server ini terlebih dahulu menggunakan perintah \`.deladmin <id>\`:\n`;
                adminServers.forEach(server => {
                    serverListText += `\n─────────────────\n`;
                    serverListText += `*Nama Server:* ${server.attributes.name}\n`;
                    serverListText += `*ID Server:* ${server.attributes.id}`;
                });
                return m.reply(serverListText);
            } else {
                const interactiveMessage = {
                    body: { text: `Anda akan menghapus admin:\n\n*Username:* ${userDetails.username}\n*ID User:* ${userDetails.id}` },
                    footer: { text: 'Tindakan ini akan menghapus user admin secara permanen!' },
                    header: { title: "KONFIRMASI PENGHAPUSAN ADMIN", hasMediaAttachment: false },
                    nativeFlowMessage: {
                        buttons: [{
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "Ya, Hapus User Admin Ini",
                                id: `${prefix}deladmin_confirm ${userId}`
                            })
                        }]
                    }
                };

                const msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                            interactiveMessage: interactiveMessage
                        }
                    }
                }, { quoted: m });
                await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
            }
        } catch (error) {
            m.reply("Gagal mendapatkan detail user. Pastikan ID User Admin benar.");
        }
    } else {
        try {
            await m.reply("proses..... jika tidak muncul berarti anda pakai wa bussines anda bisa pakai .listadmin trus ketik .deladmin angka sesuai di list");

            const userListResponse = await axios.get(`${global.domain}/api/application/users`, {
                headers: { "Authorization": "Bearer " + global.apikey }
            });
            const allUsers = userListResponse.data.data;
            const adminUsers = allUsers.filter(user => user.attributes.root_admin);

            if (adminUsers.length === 0) {
                return m.reply("Tidak ada user admin yang ditemukan di panel.");
            }

            const adminRows = adminUsers.map(user => ({
                title: user.attributes.username,
                description: `ID: ${user.attributes.id} | Email: ${user.attributes.email}`,
                id: `${prefix}deladmin ${user.attributes.id}` 
            }));

            const paramsJson = {
                title: 'Pilih Admin Untuk Dihapus',
                sections: [{
                    title: 'DAFTAR USER ADMIN',
                    highlight_label: `${adminUsers.length} Admin Tersedia`,
                    rows: adminRows
                }]
            };

            const interactiveMessage = {
                body: { text: "Silakan pilih user admin yang ingin Anda hapus." },
                footer: { text: "Manajemen Admin © ELAINA BY MANE" },
                header: { title: "PILIH ADMIN", hasMediaAttachment: false },
                nativeFlowMessage: {
                    buttons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify(paramsJson)
                    }]
                }
            };

            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                        interactiveMessage: interactiveMessage
                    }
                }
            }, { quoted: m });
    
            await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        } catch (error) {
            m.reply(`Terjadi Kesalahan:\n${error.message}`);
        }
    }
}
break;

case 'listadmin': {
    if (!isOwner) return m.reply(mess.owner);
    
    try {
        await m.reply("⏳ Mengambil daftar user admin, mohon tunggu...");
        
        const userListResponse = await axios.get(`${global.domain}/api/application/users`, {
            headers: { "Authorization": "Bearer " + global.apikey }
        });
        const allUsers = userListResponse.data.data;
        const adminUsers = allUsers.filter(user => user.attributes.root_admin);

        if (adminUsers.length === 0) {
            return m.reply("Tidak ada user admin yang ditemukan di panel.");
        }

        let listText = "*DAFTAR SEMUA USER ADMIN*\n";
        adminUsers.forEach(user => {
            listText += `\n─────────────────\n`;
            listText += `*Username:* ${user.attributes.username}\n`;
            listText += `*ID User:* ${user.attributes.id}\n`;
            listText += `*Email:* ${user.attributes.email}`;
        });
        
        m.reply(listText.trim());

    } catch (error) {
        m.reply(`Terjadi Kesalahan:\n${error.message}`);
    }
}
break;

case 'deladmin_confirm': {
    if (!isOwner) return m.reply(mess.owner);
    const userId = args[0];
    if (!userId || isNaN(userId)) return m.reply("ID User tidak valid.");

    try {
        await m.reply(`Menghapus user admin dengan ID ${userId}...`);
        await axios.delete(`${global.domain}/api/application/users/${userId}`, {
            headers: { "Authorization": "Bearer " + global.apikey }
        });
        m.reply(`✅ Sukses menghapus user admin dengan ID *${userId}*.`);
    } catch (error) {
        const errorMsg = error.response ? `Gagal menghapus user admin. Status: ${error.response.status}.` : error.message;
        return m.reply(`Terjadi Kesalahan:\n${errorMsg}\n\nPastikan ID User benar dan bukan user utama.`);
    }
}
break;

case 'addakses': {
    if (!isOwner) return m.reply(mess.owner);
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");
    
    const groupId = m.chat;
    if (global.resellergroups.includes(groupId)) return m.reply("Grup ini sudah terdaftar sebagai reseller.");

    global.resellergroups.push(groupId);
    saveResellerGroups(global.resellergroups);
    await m.reply("✅ Berhasil! Semua anggota di grup ini sekarang mendapatkan hak akses sebagai Reseller.");
}
break;

//SERVER 2
case 'addaksesv2': {
    if (!isOwner) return m.reply(mess.owner);
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");
    
    const groupId = m.chat;
    if (global.resellergroupsv2.includes(groupId)) return m.reply("Grup ini sudah terdaftar sebagai reseller untuk Server 2.");

    global.resellergroupsv2.push(groupId);
    saveResellerGroupsV2(global.resellergroupsv2);
    await m.reply("✅ Berhasil! Semua anggota di grup ini sekarang mendapatkan hak akses sebagai Reseller untuk Server 2.");
}
break;

case "1gbv2":
case "2gbv2":
case "3gbv2":
case "4gbv2":
case "5gbv2":
case "6gbv2":
case "7gbv2":
case "8gbv2":
case "9gbv2":
case "10gbv2":
case "unliv2":
case "unlimitedv2": {
    const missingSettings = [];
    if (!global.domainv2) missingSettings.push("`global.domainv2`");
    if (!global.apikeyv2) missingSettings.push("`global.apikeyv2` (ptla)");
    if (!global.capikeyv2) missingSettings.push("`global.capikeyv2` (ptlc)");

    if (missingSettings.length > 0) {
        return m.reply(`⚠️ *Konfigurasi Server 2 Belum Lengkap!*\nHarap isi variabel berikut di \`settings.js\`:\n\n${missingSettings.join('\n')}`);
    }

    if (!isOwner && !isResellerV2 && !isPremiumV2) {
        return m.reply("Perintah ini hanya bisa diakses oleh Owner, Premium, atau anggota grup Reseller Server 2.");
    }
    
    let nomor;
    let usernem;

    if (m.quoted) {
        nomor = m.quoted.sender;
        usernem = text.split(',')[0].trim().toLowerCase();
    } else if (text.includes(",")) {
        if (!isOwner) return m.reply("Hanya Owner yang dapat membuat panel untuk nomor lain.");
        const [users, nom] = text.split(",");
        if (!users || !nom) return m.reply(`Format salah. Contoh:\n.${command} username,628xxxx`);
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.trim().toLowerCase();
    } else {
        nomor = m.sender;
        usernem = text.trim().toLowerCase();
    }

    if (!usernem) return m.reply(`Username tidak boleh kosong!\n\nContoh Penggunaan:\n1. Reply pesan: \`.${command} username\`\n2. Ketik nomor: \`.${command} username,628xxx\`\n3. Untuk diri sendiri: \`.${command} username\``);

    const [onWa] = await mane.onWhatsApp(nomor.split("@")[0]);
    if (!onWa?.exists) return m.reply("❌ Nomor target tidak terdaftar di WhatsApp!");

    const paket = {
        "1gb": { ram: "1000", disk: "1000", cpu: "40" }, "2gb": { ram: "2000", disk: "1000", cpu: "60" },
        "3gb": { ram: "3000", disk: "2000", cpu: "80" }, "4gb": { ram: "4000", disk: "2000", cpu: "100" },
        "5gb": { ram: "5000", disk: "3000", cpu: "120" }, "6gb": { ram: "6000", disk: "3000", cpu: "140" },
        "7gb": { ram: "7000", disk: "4000", cpu: "160" }, "8gb": { ram: "8000", disk: "4000", cpu: "180" },
        "9gb": { ram: "9000", disk: "5000", cpu: "200" }, "10gb": { ram: "10000", disk: "5000", cpu: "220" },
        "unli": { ram: "0", disk: "0", cpu: "0" }, "unlimited": { ram: "0", disk: "0", cpu: "0" }
    };
    
    const baseCommand = command.replace('v2', '');
    const specs = paket[baseCommand];
    if (!specs) return m.reply("❌ Paket tidak valid.");

    const { ram, disk: disknya, cpu } = specs;
    const password = usernem + crypto.randomBytes(3).toString("hex");

    try {
        await m.reply(`(S2) ⏳ Memproses pembuatan panel untuk *${usernem}*...`);

        const userPayload = {
            email: `${usernem}@gmail.com`, username: usernem,
            first_name: capitalize(usernem), last_name: "ELAINA",
            language: "en", password
        };
        const userResponse = await axios.post(`${global.domainv2}/api/application/users`, userPayload, {
            headers: { Authorization: `Bearer ${global.apikeyv2}`, "Content-Type": "application/json", Accept: "application/json" }
        });
        
        const user = userResponse.data.attributes;
        
        const eggData = await axios.get(`${global.domainv2}/api/application/nests/${global.nestidv2}/eggs/${global.eggv2}`, {
            headers: { Authorization: `Bearer ${global.apikeyv2}` }
        });

        const serverPayload = {
            name: `${capitalize(usernem)} Elaina`, user: user.id, egg: parseInt(global.eggv2),
            docker_image: eggData.data.attributes.docker_image, startup: eggData.data.attributes.startup,
            environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
            limits: { memory: ram, swap: 0, disk: disknya, io: 500, cpu },
            feature_limits: { databases: 5, backups: 5, allocations: 5 },
            deploy: { locations: [parseInt(global.locv2)], dedicated_ip: false, port_range: [] }
        };
        const serverResponse = await axios.post(`${global.domainv2}/api/application/servers`, serverPayload, {
            headers: { Authorization: `Bearer ${global.apikeyv2}`, "Content-Type": "application/json", Accept: "application/json" }
        });

        const detailTeks = `*✅ Panel (Server 2) Berhasil Dibuat!*

👤 *Username:* \`${user.username}\`
🔐 *Password:* \`${password}\`
🌐 *Login:* ${global.domainv2}

🧠 *Spesifikasi Server:*
• RAM: ${ram === "0" ? "Unlimited" : `${parseInt(ram) / 1000} GB`}
• Disk: ${disknya === "0" ? "Unlimited" : `${parseInt(disknya) / 1000} GB`}
• CPU: ${cpu === "0" ? "Unlimited" : `${cpu}%`}

📝 *Catatan:* Simpan detail ini baik-baik. Masa aktif 30 hari.`;

        try {
            const preparedImage = await prepareWAMessageMedia({ image: { url: global.thumbpanel } }, { upload: mane.waUploadToServer });
            const interactiveMessage = {
                body: { text: detailTeks }, footer: { text: '© Elaina PANEL V2' },
                header: { title: "🎉 Akun Anda Siap Digunakan!", hasMediaAttachment: true, imageMessage: preparedImage.imageMessage },
                nativeFlowMessage: {
                    buttons: [
                        { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "COPY USERNAME", copy_code: user.username }) },
                        { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "COPY PASSWORD", copy_code: password }) }
                    ]
                }
            };
            const msg = generateWAMessageFromContent(nomor, { viewOnceMessage: { message: { interactiveMessage } } }, { userJid: nomor });
            await mane.relayMessage(nomor, msg.message, { messageId: msg.key.id });
        } catch (sendErr) {
            console.error("Gagal mengirim pesan interaktif, mengirim sebagai teks biasa. Error:", sendErr);
            await mane.sendMessage(nomor, { text: detailTeks });
        }

        await mane.sendMessage(m.chat, {
            text: `(S2) ✅ Selesai! Detail panel telah dikirim ke @${nomor.split('@')[0]}.`,
            mentions: [nomor]
        }, { quoted: m });

    } catch (err) {
        console.error("Gagal membuat panel Server 2:", util.inspect(err, false, null, true));
        const e = err?.response?.data?.errors?.[0]?.detail || err.message;
        return m.reply(`(S2) ❌ Gagal membuat panel.\n*Pesan Error:* ${e}`);
    }
}
break;
case 'delaksesv2': {
    if (!isOwner) return m.reply(mess.owner);
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");

    const groupId = m.chat;
    const index = global.resellergroupsv2.indexOf(groupId);

    if (index === -1) return m.reply("Grup ini tidak terdaftar sebagai reseller untuk Server 2.");

    global.resellergroupsv2.splice(index, 1);
    saveResellerGroupsV2(global.resellergroupsv2);
    await m.reply("✅ Berhasil! Hak akses reseller Server 2 untuk semua anggota di grup ini telah dicabut.");
}
break;

case "cadminv2": {
    const missingSettings = [];
    if (!global.domainv2) missingSettings.push("`global.domainv2`");
    if (!global.apikeyv2) missingSettings.push("`global.apikeyv2` (ptla)");

    if (missingSettings.length > 0) {
        return m.reply(`⚠️ *Konfigurasi Server 2 Belum Lengkap!*\nHarap isi variabel berikut di \`settings.js\`:\n\n${missingSettings.join('\n')}`);
    }

    if (!isOwner && !isPremiumV2) return m.reply(mess.ress);
    
    let nomor;
    let usernem;

    // Logika baru untuk menentukan target
    if (m.quoted) {
        nomor = m.quoted.sender;
        usernem = text.split(',')[0].trim().toLowerCase();
    } else if (text.includes(",")) {
        if (!isOwner) return m.reply("Hanya Owner yang dapat membuat akun admin untuk nomor lain.");
        const [users, nom] = text.split(",");
        if (!users || !nom) return m.reply(`Format salah. Contoh:\n.cadminv2 username,628xxxx`);
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.trim().toLowerCase();
    } else {
        nomor = m.sender;
        usernem = text.trim().toLowerCase();
    }
    
    if (!usernem) return m.reply(`Username tidak boleh kosong!\n\nContoh:\n.cadminv2 namauser`);

    const [onWa] = await mane.onWhatsApp(nomor.split("@")[0]);
    if (!onWa?.exists) return m.reply("Nomor target tidak terdaftar di WhatsApp!");

    let password = usernem + crypto.randomBytes(2).toString('hex');
    
    try {
        await m.reply(`(S2) ⏳ Memproses pembuatan akun admin untuk *${usernem}*...`);

        const userPayload = {
            email: `${usernem}@gmail.com`,
            username: usernem,
            first_name: capitalize(usernem), last_name: "Admin",
            root_admin: true, language: "en", password
        };
        const userResponse = await axios.post(`${global.domainv2}/api/application/users`, userPayload, {
            headers: { Accept: "application/json", "Content-Type": "application/json", Authorization: `Bearer ${global.apikeyv2}` }
        });

        const user = userResponse.data.attributes;

        const detailTeks = `*✅ Akun Admin Panel (Server 2) Anda Telah Siap!*

👤 *Username:* \`${user.username}\`
🔐 *Password:* \`${password}\`
🌐 *Login:* ${global.domainv2}

*Penting:* Akun ini memiliki akses penuh. Gunakan dengan bijak.`;
        
        try {
            const preparedImage = await prepareWAMessageMedia({ image: { url: global.thumbpanel } }, { upload: mane.waUploadToServer });
            const interactiveMessage = {
                body: { text: detailTeks }, footer: { text: '© ELAINA PANEL V2' },
                header: { title: "✅ Akun Admin Siap!", hasMediaAttachment: true, imageMessage: preparedImage.imageMessage },
                nativeFlowMessage: {
                    buttons: [
                        { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "COPY USERNAME", copy_code: user.username }) },
                        { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "COPY PASSWORD", copy_code: password }) }
                    ]
                }
            };
            const msg = generateWAMessageFromContent(nomor, { viewOnceMessage: { message: { interactiveMessage } } }, { userJid: nomor });
            await mane.relayMessage(nomor, msg.message, { messageId: msg.key.id });
        } catch (sendErr) {
            console.error("Gagal mengirim pesan interaktif, mengirim sebagai teks biasa. Error:", sendErr);
            await mane.sendMessage(nomor, { text: detailTeks });
        }

        if (nomor !== m.sender) {
            await mane.sendMessage(m.chat, {
                text: `(S2) ✅ Selesai! Detail admin telah dikirim ke @${nomor.split('@')[0]}.`,
                mentions: [nomor]
            }, { quoted: m });
        } else {
            await m.reply(`(S2) ✅ Selesai! Detail admin telah dikirim ke chat pribadi Anda.`);
        }

    } catch (err) {
        console.error("Gagal membuat admin Server 2:", util.inspect(err, false, null, true));
        const e = err?.response?.data?.errors?.[0]?.detail || err.message;
        return m.reply(`(S2) ❌ Gagal membuat admin.\n*Pesan Error:* ${e}`);
    }
}
break;

case 'delpanelv2': {
    if (!isOwner) return m.reply(mess.owner);

    if (args[0]) {
        const serverId = args[0];
        if (isNaN(serverId)) return m.reply("ID Server harus berupa angka.");

        try {
            const serverDetailsResponse = await axios.get(`${global.domainv2}/api/application/servers/${serverId}`, {
                headers: { "Authorization": "Bearer " + global.apikeyv2 }
            });
            const serverDetails = serverDetailsResponse.data.attributes;
            const serverName = serverDetails.name;
            const userId = serverDetails.user;

            const userDetailsResponse = await axios.get(`${global.domainv2}/api/application/users/${userId}`, {
                headers: { "Authorization": "Bearer " + global.apikeyv2 }
            });
            const isUserAdmin = userDetailsResponse.data.attributes.root_admin;

            let buttons = [];

            if (!isUserAdmin) {
                buttons.unshift({
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Hapus Panel + User",
                        id: `${prefix}delpanel_user_and_panelv2 ${serverId}`
                    })
                });
            }

            buttons.push({
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "Hapus Panel Saja",
                    id: `${prefix}delpanel_onlyv2 ${serverId}`
                })
            });

            const interactiveMessage = {
                body: { text: `Anda telah memilih server:\n\n*Nama:* ${serverName}\n*ID:* ${serverId}\n*Status User:* ${isUserAdmin ? 'Admin' : 'Bukan Admin'}` },
                footer: { text: 'Tindakan ini tidak dapat diurungkan!' },
                header: { title: "KONFIRMASI PENGHAPUSAN", hasMediaAttachment: false },
                nativeFlowMessage: {
                    buttons: buttons
                }
            };

            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                        interactiveMessage: interactiveMessage
                    }
                }
            }, { quoted: m });

            await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        } catch (error) {
            m.reply("Gagal mendapatkan detail server. Pastikan ID Server benar.");
        }

    } else {
        try {
            await m.reply("proses..... jika tidak muncul berarti anda pakai wa bussines anda bisa pakai .listpanel trus ketik .delpanel angka sesuai di list");

            const serverListResponse = await axios.get(`${global.domainv2}/api/application/servers`, {
                headers: {
                    "Accept": "application/json",
                    "Authorization": "Bearer " + global.apikeyv2
                }
            });

            const servers = serverListResponse.data.data;
            if (!servers || servers.length === 0) {
                return m.reply("Tidak ada server yang ditemukan di panel.");
            }

            const serverRows = servers.map(server => ({
    title: server.attributes.name,
    description: `ID: ${server.attributes.id} | RAM: ${server.attributes.limits.memory} MB`,
    id: `${prefix}delpanelv2 ${server.attributes.id}` 
}));
            
            const paramsJson = {
                title: 'Pilih Server Untuk Dihapus',
                sections: [{
                    title: 'DAFTAR SERVER PANEL',
                    highlight_label: `${servers.length} Server Tersedia`,
                    rows: serverRows
                }]
            };

            
            const interactiveMessage = {
                body: { text: "Silakan pilih server yang ingin Anda hapus." },
                footer: { text: "Manajemen Panel © ELAINA" },
                header: { title: "PILIH SERVER", hasMediaAttachment: false },
                nativeFlowMessage: {
                    buttons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify(paramsJson)
                    }]
                }
            };
    
            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                        interactiveMessage: interactiveMessage
                    }
                }
            }, { quoted: m });
    
            await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        } catch (error) {
            m.reply(`Terjadi Kesalahan:\n${error.message}`);
        }
    }
}
break;
case 'listpanelv2': {
    if (!isOwner) return m.reply(mess.owner);
    
    try {
        await m.reply("⏳ Mengambil daftar server dan user, mohon tunggu...");
        
        const serverListResponse = await axios.get(`${global.domainv2}/api/application/servers`, {
            headers: { "Authorization": "Bearer " + global.apikeyv2 }
        });

        const servers = serverListResponse.data.data;
        if (!servers || servers.length === 0) {
            return m.reply("Tidak ada server yang ditemukan di panel.");
        }

        let listText = "*DAFTAR SEMUA PANEL & USER*\n";
        for (const server of servers) {
            try {
                const userDetails = await axios.get(`${global.domainv2}/api/application/users/${server.attributes.user}`, {
                    headers: { "Authorization": "Bearer " + global.apikeyv2 }
                });
                const username = userDetails.data.attributes.username;
                const isAdmin = userDetails.data.attributes.root_admin;
                listText += `\n─────────────────\n`;
                listText += `*Server:* ${server.attributes.name}\n`;
                listText += `*ID Server:* ${server.attributes.id}\n`;
                listText += `*User:* ${username} ${isAdmin ? '*(Admin)*' : ''}`;
            } catch (userError) {
                listText += `\n─────────────────\n`;
                listText += `*Server:* ${server.attributes.name}\n`;
                listText += `*ID Server:* ${server.attributes.id}\n`;
                listText += `*User:* (Gagal mengambil data)`;
            }
        }
        
        m.reply(listText.trim());

    } catch (error) {
        m.reply(`Terjadi Kesalahan:\n${error.message}`);
    }
}
break;

case 'delpanel_onlyv2': {
    if (!isOwner) return m.reply(mess.owner);
    const serverId = args[0];
    if (!serverId || isNaN(serverId)) return m.reply("ID Server tidak valid.");

    try {
        await m.reply(`Menghapus server dengan ID ${serverId}...`);
        await axios.delete(`${global.domainv2}/api/application/servers/${serverId}?force=true`, {
            headers: { "Authorization": "Bearer " + global.apikeyv2 }
        });
        m.reply(`✅ Sukses menghapus server dengan ID *${serverId}*.\n\nCatatan: User yang terkait tidak ikut terhapus.`);
    } catch (error) {
        const errorMsg = error.response ? `Gagal menghapus server. Status: ${error.response.status}.` : error.message;
        return m.reply(`Terjadi Kesalahan:\n${errorMsg}\n\nPastikan ID Server benar.`);
    }
}
break;

case 'delpanel_user_and_panelv2': {
    if (!isOwner) return m.reply(mess.owner);
    const serverId = args[0];
    if (!serverId || isNaN(serverId)) return m.reply("ID Server tidak valid.");

    try {
        await m.reply(`⏳ Memulai proses penghapusan untuk server ID ${serverId}...`);

        const serverDetails = await axios.get(`${global.domainv2}/api/application/servers/${serverId}`, {
            headers: { "Authorization": "Bearer " + global.apikeyv2 }
        });

        const userId = serverDetails.data.attributes.user;
        const serverName = serverDetails.data.attributes.name;

        const userDetails = await axios.get(`${global.domainv2}/api/application/users/${userId}`, {
            headers: { "Authorization": "Bearer " + global.apikeyv2 }
        });
        
        if (userDetails.data.attributes.root_admin) {
            await m.reply(`⚠️ User terkait adalah Admin. Hanya server [${serverName}] yang akan dihapus.`);
            await axios.delete(`${global.domainv2}/api/application/servers/${serverId}?force=true`, {
                headers: { "Authorization": "Bearer " + global.apikeyv2 }
            });
            await m.reply(`✅ Server [${serverName}] berhasil dihapus. User Admin tidak dihapus.`);
        } else {
            await axios.delete(`${global.domainv2}/api/application/servers/${serverId}?force=true`, {
                headers: { "Authorization": "Bearer " + global.apikeyv2 }
            });
            await m.reply(`✅ Server [${serverName}] berhasil dihapus.`);
            
            await axios.delete(`${global.domainv2}/api/application/users/${userId}`, {
                headers: { "Authorization": "Bearer " + global.apikeyv2 }
            });
            await m.reply(`✅ User terkait dengan ID ${userId} juga berhasil dihapus.`);
        }
    } catch (error) {
        let errorMsg = error.response ? `Gagal. Status: ${error.response.status}. Mungkin server atau user sudah dihapus.` : error.message;
        return m.reply(`Terjadi Kesalahan:\n${errorMsg}`);
    }
}
break;
case 'deladminv2': {
    if (!isOwner) return m.reply(mess.owner);

    if (args[0]) {
        const userId = args[0];
        if (isNaN(userId)) return m.reply("ID User harus berupa angka.");

        try {
            const userDetailsResponse = await axios.get(`${global.domainv2}/api/application/users/${userId}`, {
                headers: { "Authorization": "Bearer " + global.apikeyv2 }
            });
            const userDetails = userDetailsResponse.data.attributes;

            if (!userDetails.root_admin) {
                return m.reply(`User dengan ID ${userId} bukan seorang admin.`);
            }

            const serverListResponse = await axios.get(`${global.domainv2}/api/application/servers`, {
                headers: { "Authorization": "Bearer " + global.apikeyv2 }
            });
            const allServers = serverListResponse.data.data;
            const adminServers = allServers.filter(server => server.attributes.user == userId);

            if (adminServers.length > 0) {
                let serverListText = `*Gagal!* User admin *${userDetails.username}* tidak bisa dihapus karena masih memiliki server berikut. Anda harus menghapus server ini terlebih dahulu menggunakan perintah \`.deladmin <id>\`:\n`;
                adminServers.forEach(server => {
                    serverListText += `\n─────────────────\n`;
                    serverListText += `*Nama Server:* ${server.attributes.name}\n`;
                    serverListText += `*ID Server:* ${server.attributes.id}`;
                });
                return m.reply(serverListText);
            } else {
                const interactiveMessage = {
                    body: { text: `Anda akan menghapus admin:\n\n*Username:* ${userDetails.username}\n*ID User:* ${userDetails.id}` },
                    footer: { text: 'Tindakan ini akan menghapus user admin secara permanen!' },
                    header: { title: "KONFIRMASI PENGHAPUSAN ADMIN", hasMediaAttachment: false },
                    nativeFlowMessage: {
                        buttons: [{
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "Ya, Hapus User Admin Ini",
                                id: `${prefix}deladmin_confirmv2 ${userId}`
                            })
                        }]
                    }
                };

                const msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                            interactiveMessage: interactiveMessage
                        }
                    }
                }, { quoted: m });
                await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
            }
        } catch (error) {
            m.reply("Gagal mendapatkan detail user. Pastikan ID User Admin benar.");
        }
    } else {
        try {
            await m.reply("proses..... jika tidak muncul berarti anda pakai wa bussines anda bisa pakai .listadmin trus ketik .deladmin angka sesuai di list");

            const userListResponse = await axios.get(`${global.domainv2}/api/application/users`, {
                headers: { "Authorization": "Bearer " + global.apikeyv2 }
            });
            const allUsers = userListResponse.data.data;
            const adminUsers = allUsers.filter(user => user.attributes.root_admin);

            if (adminUsers.length === 0) {
                return m.reply("Tidak ada user admin yang ditemukan di panel.");
            }

            const adminRows = adminUsers.map(user => ({
    title: user.attributes.username,
    description: `ID: ${user.attributes.id} | Email: ${user.attributes.email}`,
    id: `${prefix}deladminv2 ${user.attributes.id}` 
}));

            const paramsJson = {
                title: 'Pilih Admin Untuk Dihapus',
                sections: [{
                    title: 'DAFTAR USER ADMIN',
                    highlight_label: `${adminUsers.length} Admin Tersedia`,
                    rows: adminRows
                }]
            };

            const interactiveMessage = {
                body: { text: "Silakan pilih user admin yang ingin Anda hapus." },
                footer: { text: "Manajemen Admin © ELAINA" },
                header: { title: "PILIH ADMIN", hasMediaAttachment: false },
                nativeFlowMessage: {
                    buttons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify(paramsJson)
                    }]
                }
            };

            const msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                        interactiveMessage: interactiveMessage
                    }
                }
            }, { quoted: m });
    
            await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        } catch (error) {
            m.reply(`Terjadi Kesalahan:\n${error.message}`);
        }
    }
}
break;

case 'listadminv2': {
    if (!isOwner) return m.reply(mess.owner);
    
    try {
        await m.reply("⏳ Mengambil daftar user admin, mohon tunggu...");
        
        const userListResponse = await axios.get(`${global.domainv2}/api/application/users`, {
            headers: { "Authorization": "Bearer " + global.apikeyv2 }
        });
        const allUsers = userListResponse.data.data;
        const adminUsers = allUsers.filter(user => user.attributes.root_admin);

        if (adminUsers.length === 0) {
            return m.reply("Tidak ada user admin yang ditemukan di panel.");
        }

        let listText = "*DAFTAR SEMUA USER ADMIN*\n";
        adminUsers.forEach(user => {
            listText += `\n─────────────────\n`;
            listText += `*Username:* ${user.attributes.username}\n`;
            listText += `*ID User:* ${user.attributes.id}\n`;
            listText += `*Email:* ${user.attributes.email}`;
        });
        
        m.reply(listText.trim());

    } catch (error) {
        m.reply(`Terjadi Kesalahan:\n${error.message}`);
    }
}
break;

case 'deladmin_confirmv2': {
    if (!isOwner) return m.reply(mess.owner);
    const userId = args[0];
    if (!userId || isNaN(userId)) return m.reply("ID User tidak valid.");

    try {
        await m.reply(`Menghapus user admin dengan ID ${userId}...`);
        await axios.delete(`${global.domainv2}/api/application/users/${userId}`, {
            headers: { "Authorization": "Bearer " + global.apikeyv2 }
        });
        m.reply(`✅ Sukses menghapus user admin dengan ID *${userId}*.`);
    } catch (error) {
        const errorMsg = error.response ? `Gagal menghapus user admin. Status: ${error.response.status}.` : error.message;
        return m.reply(`Terjadi Kesalahan:\n${errorMsg}\n\nPastikan ID User benar dan bukan user utama.`);
    }
}
break;


case 'delakses': {
    if (!isOwner) return m.reply(mess.owner);
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");

    const groupId = m.chat;
    const index = global.resellergroups.indexOf(groupId);

    if (index === -1) return m.reply("Grup ini tidak terdaftar sebagai reseller.");

    global.resellergroups.splice(index, 1);
    saveResellerGroups(global.resellergroups);
    await m.reply("✅ Berhasil! Hak akses reseller untuk semua anggota di grup ini telah dicabut.");
}
break;

case 'listreseller': {
    if (!isOwner) return m.reply(mess.owner);

    const activeResellerGroups = global.resellergroups;

    if (!activeResellerGroups || activeResellerGroups.length === 0) {
        return m.reply("Saat ini tidak ada grup reseller yang terdaftar.");
    }

    let text = "*DAFTAR GRUP RESELLER AKTIF*\n\n";
    for (const groupId of activeResellerGroups) {
        try {
            const metadata = await mane.groupMetadata(groupId);
            text += `• *Nama Grup:* ${metadata.subject}\n`;
            text += `  *ID Grup:* ${groupId}\n\n`;
        } catch (e) {
            text += `• Gagal mengambil data untuk ID: ${groupId}\n\n`;
        }
    }
    m.reply(text.trim());
}
break;
case 'listram': {
    const isReseller = m.isGroup && global.resellergroups.includes(m.chat);
    if (!isOwner && !isReseller) {
        return m.reply("Perintah ini hanya bisa diakses oleh Owner atau anggota grup Reseller.");
    }

    const paket = {
        "1gb": { ram: "1000", disk: "1000", cpu: "40" },
        "2gb": { ram: "2000", disk: "1000", cpu: "60" },
        "3gb": { ram: "3000", disk: "2000", cpu: "80" },
        "4gb": { ram: "4000", disk: "2000", cpu: "100" },
        "5gb": { ram: "5000", disk: "3000", cpu: "120" },
        "6gb": { ram: "6000", disk: "3000", cpu: "140" },
        "7gb": { ram: "7000", disk: "4000", cpu: "160" },
        "8gb": { ram: "8000", disk: "4000", cpu: "180" },
        "9gb": { ram: "9000", disk: "5000", cpu: "200" },
        "10gb": { ram: "10000", disk: "5000", cpu: "220" },
        "unli": { ram: "0", disk: "0", cpu: "0" }
    };

    let listText = "*DAFTAR PAKET RAM TERSEDIA*\n\n";
    listText += "Gunakan perintah `.paket username`\nContoh: `.1gb mane`\n\n";

    for (const [key, value] of Object.entries(paket)) {
        const ram = value.ram === "0" ? "Unlimited" : `${parseInt(value.ram) / 1000} GB`;
        const disk = value.disk === "0" ? "Unlimited" : `${parseInt(value.disk) / 1000} GB`;
        const cpu = value.cpu === "0" ? "Unlimited" : `${value.cpu}%`;
        
        listText += `─────────────────\n`;
        listText += `*Paket:* ${key}\n`;
        listText += `• RAM: ${ram}\n`;
        listText += `• Disk: ${disk}\n`;
        listText += `• CPU: ${cpu}\n`;
    }

    m.reply(listText.trim());
}
break;
case 'self':
case 'public': {
    if (!isOwner) return m.reply('Perintah ini hanya untuk Owner.');

    const newMode = command === 'public';
    mane.public = newMode;
    
    if (global.botSettings && typeof saveSettings === 'function') {
        global.botSettings.isPublic = newMode;
        saveSettings(global.botSettings);
    }
    
    const modeStatus = newMode ? 'PUBLIC' : 'SELF';
    
    console.log(chalk.yellow(
        `[MODE CHANGE] Mode diubah ke ${modeStatus} oleh ${m.pushName || m.sender.split('@')[0]}`
    ));
    
    await m.reply(`✅ Mode bot berhasil diubah ke: *${modeStatus}*`);
    
    if (m.isGroup) {
        const groupInfo = await mane.groupMetadata(m.chat).catch(e => null);
        const groupName = groupInfo?.subject || 'Unknown Group';
        console.log(chalk.yellow(`[GROUP INFO] Nama Grup: ${groupName} | ID: ${m.chat}`));
    }
    }
    break;

case 'mute': {
    if (!isOwner) return m.reply("Hanya owner yang bisa menggunakan perintah ini.");
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");

    if (global.mutedGroups.includes(m.chat)) {
        return m.reply("Grup ini sudah di-mute sebelumnya.");
    }

    global.mutedGroups.push(m.chat);
    saveMutedGroups(global.mutedGroups);
    console.log(chalk.yellow(`[MUTE] Grup ${m.chat} telah dimute`));
    await m.reply("✅ Bot berhasil di-mute di grup ini.");
    break;
}

case 'unmute': {
    if (!isOwner) return m.reply("Hanya owner yang bisa menggunakan perintah ini.");
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");

    const index = global.mutedGroups.indexOf(m.chat);
    if (index === -1) {
        return m.reply("Grup ini tidak sedang dalam mode mute.");
    }

    global.mutedGroups.splice(index, 1);
    saveMutedGroups(global.mutedGroups);
    console.log(chalk.yellow(`[UNMUTE] Grup ${m.chat} telah diunmute`));
    await m.reply("✅ Bot berhasil di-unmute di grup ini.");
    }
    break;
    
case 'owner': {
    try {
        await mane.sendMessage(m.chat, { react: { text: "👑", key: m.key } });

        const ownerList = global.owner.filter(owner => owner && owner.trim() !== '');

        if (ownerList.length === 0) {
            return m.reply("Nomor owner belum diatur di file settings.js.");
        }

        const ownerName = global.namaOwner || "Danzz";
        const ownerImageUrl = global.thumbpanel;

        let captionText = `*-- My Creator(s) --*\n\n*Nama:* ${ownerName}\n\n`;

        ownerList.forEach((ownerNumber, index) => {
            captionText += `*Kontak ${index + 1}:* wa.me/${ownerNumber}\n`;
        });

        captionText += "\nJangan di-spam ya kak!";

        await mane.sendMessage(m.chat, {
            image: { url: ownerImageUrl },
            caption: captionText.trim(),
            contextInfo: {
                mentionedJid: [m.sender]
            }
        }, { quoted: m });

    } catch (e) {
        console.error("Gagal mengirim info owner:", e);
        const ownerList = global.owner.filter(owner => owner && owner.trim() !== '');
        if (ownerList.length > 0) {
            let fallbackText = "Terjadi error, ini kontak owner saya:\n\n";
            ownerList.forEach((ownerNumber, index) => {
                fallbackText += `*Kontak ${index + 1}:* wa.me/${ownerNumber}\n`;
            });
            m.reply(fallbackText.trim());
        } else {
            m.reply("Terjadi error dan nomor owner belum diatur.");
        }
    }
}
break;
case 'brat': {
    if (!m.isGroup) return m.reply("Fitur ini khusus untuk grup ya!");

    let text;

    if (args.length >= 1) {
        text = args.slice(0).join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        return m.reply("Masukkan teks atau reply teks yang ingin dijadikan sticker!");
    }

    if (!text) {
        return m.reply(`Penggunaan: ${prefix + command} [teks]`);
    }

    const tmpDir = './tmp';
    if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
    }
    
    const stickerPath = path.join(tmpDir, `brat_${Date.now()}.webp`);

    try {
        await mane.sendMessage(m.chat, { react: { text: "🕐", key: m.key } });
        
        const ngawiStikBuffer = await getBuffer(`https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isVideo=false&delay=500`);
        
        if (!ngawiStikBuffer || ngawiStikBuffer.length < 1024) {
            throw new Error("API tidak mengembalikan gambar yang valid. Coba lagi nanti.");
        }
        
        fs.writeFileSync(stickerPath, ngawiStikBuffer);
        
        await mane.sendImageAsSticker(m.chat, stickerPath, m, {
            packname: `𓄯ִ ── ꯭𐑈ƚꪱִ𝖼𝗄ᧉׄ𝗋 ᎓`,
            author: `Aina-md`
        });

    } catch (error) {
        console.error("Error generating brat sticker:", error);
        return m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
    } finally {
        if (fs.existsSync(stickerPath)) {
            fs.unlinkSync(stickerPath);
        }
    }
}
break;

case 'idch':
case 'cekidch': {
    if (!text) return reply("Silakan masukkan link channel WhatsApp.");
    if (!text.includes("https://whatsapp.com/channel/")) return reply("Link tautan channel tidak valid.");

    try {
        const channelCode = text.split('https://whatsapp.com/channel/')[1];
        const res = await mane.newsletterMetadata("invite", channelCode);

        if (!res || !res.id) {
            return reply("Gagal mendapatkan informasi channel. Pastikan link yang Anda berikan benar dan channel tersebut publik.");
        }

        const verificationStatus = res.verification === "VERIFIED" ? "Terverifikasi" : "Tidak Terverifikasi";

        const teks = `*Detail Informasi Channel*\n\n` +
                     `*ID :* ${res.id}\n` +
                     `*Nama :* ${res.name}\n` +
                     `*Total Pengikut :* ${res.subscribers}\n` +
                     `*Status :* ${res.state}\n` +
                     `*Verifikasi :* ${verificationStatus}`;

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                        "deviceListMetadata": {},
                        "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: {
                        body: {
                            text: teks
                        },
                        footer: {
                            text: '© Elaina Assistant'
                        },
                        nativeFlowMessage: {
                            buttons: [{
                                "name": "cta_copy",
                                "buttonParamsJson": JSON.stringify({
                                    "display_text": "Salin ID Channel",
                                    "copy_code": res.id
                                })
                            }],
                        },
                    },
                },
            },
        }, {
            quoted: m
        });

        await mane.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        });

    } catch (e) {
        console.error("Error pada perintah 'cekidch':", e);
        reply("Terjadi kesalahan. Gagal mengambil informasi channel. Pastikan link yang Anda berikan valid.");
    }
}
break; 
case "cekidgc": {
    if (!isOwner) return m.reply(mess.owner);

    await m.reply("⏳ Sedang mengambil daftar grup, mohon tunggu...");

    try {
        let getGroups = await mane.groupFetchAllParticipating();
        let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1]);
        let anu = groups.map((v) => v.id);
        let teks = `⬣ *LIST GROUP DI BAWAH*\n\nTotal Group : ${anu.length} Group\n\n`;
        
        for (let x of anu) {
            let metadata2 = await mane.groupMetadata(x);
            teks += `◉ Nama : ${metadata2.subject}\n◉ ID : ${metadata2.id}\n◉ Member : ${metadata2.participants.length}\n\n────────────────────────\n\n`;
        }

        await m.reply(teks.trim());

    } catch (e) {
        console.error(e);
        await m.reply("Terjadi kesalahan saat mengambil data grup.");
    }
}
break;

case 'tourl': {
    if (!m.quoted) return m.reply('Reply media (foto, video, dokumen) yang ingin diubah ke link!');
    
    const tmpDir = './tmp';
    if (!fs.existsSync(tmpDir)) {
        fs.mkdirSync(tmpDir, { recursive: true });
    }

    const mime = (m.quoted.msg || m.quoted).mimetype || '';
    if (!mime) {
        return m.reply('Gagal mendeteksi jenis media!');
    }
    
    const { fromBuffer } = require('file-type');
    const quotedBuffer = await m.quoted.download();
    const type = await fromBuffer(quotedBuffer);
    const extension = type ? type.ext : mime.split('/')[1] || 'bin';

    if (!extension) {
        console.error("Gagal mendapatkan ekstensi untuk mime-type:", mime);
        return m.reply("Tidak bisa menentukan ekstensi file untuk media ini.");
    }
    
    m.reply('⏳ Mengupload media ke Catbox.moe...');
    
    try {
        const tmpFile = path.join(tmpDir, `${getRandom()}.${extension}`);
        fs.writeFileSync(tmpFile, quotedBuffer);

        const form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('fileToUpload', fs.createReadStream(tmpFile));

        const res = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: form.getHeaders()
        });

        const url = res.data;
        fs.unlinkSync(tmpFile);

        const teks = `✅ *Sukses Upload!*\n\n🔗 Link: ${url}`;

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: {
                        body: { text: teks },
                        footer: { text: "Link Hosting via Catbox.moe" },
                        header: { title: "Media Telah Diupload!", hasMediaAttachment: false },
                        nativeFlowMessage: {
                            buttons: [{
                                name: "cta_copy",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "SALIN LINK",
                                    copy_code: url
                                })
                            }]
                        }
                    }
                }
            }
        }, { quoted: m });

        await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (err) {
        console.error("Error 'tourl':", err);
        m.reply('❌ Gagal upload ke Catbox. Coba lagi atau pastikan medianya tidak kosong.');
    }
}
break;

case 'tqto': {
    await mane.sendMessage(m.chat, { react: { text: "💝", key: m.key } });

    const teks = `
Terima kasih sebesar-besarnya kepada:

💠 *Allah SWT* — Atas segala Rahmat & Karunia-Nya  
💠 *Danzz*, *FIXZ* — creator sanhua
💠 *Mane*, *Ofc* — recode Sc Sanhua
💠 *Terimakasih telah menggunakan sc elaina ini*
💬 Tetap semangat dan jangan lupa berdoa 🙏
    `.trim();

    const preparedImage = await prepareWAMessageMedia({
        image: { url: global.thumbpanel } 
    }, { upload: mane.waUploadToServer });

    const interactiveMessage = {
        body: { text: teks },
        footer: { text: 'ELAINA Assistant - All Rights Reserved' },
        header: {
            title: "✨ TQTO - Credits & Thanks ✨",
            hasMediaAttachment: true,
            imageMessage: preparedImage.imageMessage
        },
        nativeFlowMessage: {
            buttons: [{
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                    display_text: "COPY UCAPAN",
                    copy_code: teks
                })
            }]
        }
    };

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage
            }
        }
    }, { quoted: m });

    await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;
case 'addowner': {
    if (!isOwner) return m.reply(mess.owner);

    let newOwner;
    if (m.quoted) {
        newOwner = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        
        const validJids = m.mentionedJid.filter(jid => jid.endsWith('@s.whatsapp.net'));
        if (validJids.length > 0) {
            newOwner = validJids[0].split('@')[0];
        } else {
            return m.reply("di wajibkan reply pesan");
        }
    } else {
        newOwner = args[0] ? args[0].replace(/[^0-9]/g, '') : null;
    }

    if (!newOwner) return m.reply("Gagal menemukan target.\n\n*Cara Penggunaan:*\n1. Balas (reply) pesan target\n2. Tag target (@user)\n3. Masukkan nomor telepon (628...)\n\n*Contoh:*\n.addowner @target");

    if (global.owner.includes(newOwner)) {
        const ownerJid = `${newOwner}@s.whatsapp.net`;
        return mane.sendMessage(m.chat, {
            text: `@${newOwner} sudah terdaftar sebagai owner.`,
            mentions: [ownerJid]
        }, { quoted: m });
    }

    global.owner.push(newOwner);
    await saveOwnerToSettingsFile();
    
    const ownerJid = `${newOwner}@s.whatsapp.net`;
    await mane.sendMessage(m.chat, {
        text: `✅ Berhasil! @${newOwner} sekarang menjadi owner.\nPerubahan telah disimpan permanen.`,
        mentions: [ownerJid]
    }, { quoted: m });
}
break;
case 'delowner': {
    if (!isOwner) return m.reply(mess.owner);

    let target;
    if (m.quoted) {
        target = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {

        const validJids = m.mentionedJid.filter(jid => jid.endsWith('@s.whatsapp.net'));
        if (validJids.length > 0) {
            target = validJids[0].split('@')[0];
        } else {
            return m.reply("di wajibkan reply pesan");
        }
    } else {
        target = args[0] ? args[0].replace(/[^0-9]/g, '') : null;
    }

    if (!target) return m.reply("Gagal menemukan target.\n\n*Cara Penggunaan:*\n1. Balas (reply) pesan target\n2. Tag target (@user)\n3. Masukkan nomor telepon (628...)\n\n*Contoh:*\n.delowner @target");

    const ownerIndex = global.owner.indexOf(target);
    if (ownerIndex === -1) {
        const targetJid = `${target}@s.whatsapp.net`;
        return mane.sendMessage(m.chat, {
            text: `@${target} tidak ada dalam daftar owner.`,
            mentions: [targetJid]
        }, { quoted: m });
    }

    global.owner.splice(ownerIndex, 1);
    await saveOwnerToSettingsFile();
    
    const targetJid = `${target}@s.whatsapp.net`;
    await mane.sendMessage(m.chat, {
        text: `✅ Berhasil! @${target} telah dihapus dari daftar owner.\nPerubahan telah disimpan permanen.`,
        mentions: [targetJid]
    }, { quoted: m });
}
break;

case 'backup': {
    if (!isCreator) return m.reply("Perintah ini khusus untuk dijalankan dari nomor Bot itu sendiri.");
    
    try {
        await m.reply("⏳ Sedang membuat file backup, proses ini mungkin memakan waktu beberapa saat...");

        const backupFileName = `backup-mane-${Date.now()}.zip`;
        
        const filesToBackup = fs.readdirSync('./').filter(item => 
            ![
                "node_modules", 
                "session", 
                "package-lock.json",
                ".npm",
                backupFileName
            ].includes(item) && !item.endsWith('.zip')
        ).join(" ");

        if (!filesToBackup) {
            return m.reply("Tidak ada file yang bisa di-backup.");
        }

        execSync(`zip -r ${backupFileName} ${filesToBackup}`);

        await mane.sendMessage(
            m.chat,
            {
                document: fs.readFileSync(`./${backupFileName}`),
                mimetype: "application/zip",
                fileName: backupFileName,
            },
            { quoted: m }
        );

        fs.unlinkSync(`./${backupFileName}`);

    } catch (error) {
        console.error("Backup Error:", error);
        m.reply(`Terjadi kesalahan saat membuat backup: ${error.message}`);
    }
}
break;
case 'remini':
case 'hd': {
    const availableScaleRatio = [2, 4];

    const imgupscale = {
        req: async (imagePath, scaleRatio) => {
            const FormData = require('form-data');
            const fs = require('fs');
            const axios = require('axios');
            const form = new FormData();
            form.append('myfile', fs.createReadStream(imagePath));
            form.append('scaleRadio', scaleRatio.toString());

            const response = await axios.request({
                method: 'POST',
                url: 'https://get1.imglarger.com/api/UpscalerNew/UploadNew',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/5.37.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/5.37.36',
                    'Accept': 'application/json, text/plain, */*',
                    'origin': 'https://imgupscaler.com',
                    'referer': 'https://imgupscaler.com/',
                    ...form.getHeaders()
                },
                data: form
            });
            return response.data;
        },

        cek: async (code, scaleRatio) => {
            const axios = require('axios');
            const response = await axios.request({
                method: 'POST',
                url: 'https://get1.imglarger.com/api/UpscalerNew/CheckStatusNew',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/5.37.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/5.37.36',
                    'Accept': 'application/json, text/plain, */*',
                    'Content-Type': 'application/json',
                    'origin': 'https://imgupscaler.com',
                    'referer': 'https://imgupscaler.com/'
                },
                data: JSON.stringify({ code, scaleRadio: scaleRatio })
            });
            return response.data;
        },

        upscale: async (imagePath, scaleRatio, maxRetries = 30, retryDelay = 2000) => {
            const uploadResult = await imgupscale.req(imagePath, scaleRatio);
            if (uploadResult.code !== 200) {
                throw new Error(`Upload failed: ${uploadResult.msg}`);
            }

            const { code } = uploadResult.data;
            for (let i = 0; i < maxRetries; i++) {
                const statusResult = await imgupscale.cek(code, scaleRatio);

                if (statusResult.code === 200 && statusResult.data.status === 'success') {
                    return {
                        success: true,
                        downloadUrls: statusResult.data.downloadUrls
                    };
                }

                if (statusResult.data.status === 'error') {
                    throw new Error('Processing failed on server');
                }
                await new Promise(resolve => setTimeout(resolve, retryDelay));
            }
            throw new Error('Processing timeout - maximum retries exceeded');
        }
    };

    if (!m.quoted || !/image/.test(m.quoted.mimetype || '')) {
        return m.reply('Reply gambar dengan perintah .hd 2x atau .hd 4x');
    }

    const scale = args[0]?.replace(/x/i, '') || '2';
    if (!availableScaleRatio.includes(Number(scale))) {
        return m.reply('Pilih resolusi: 2x atau 4x');
    }

    let tmpPath;
    try {
        await m.reply('⏳ Sedang memproses gambar, mohon tunggu...');
        
const buffer = await mane.downloadMediaMessage(m.quoted);
        const tmpDir = './tmp';
        const fs = require('fs');
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }
        
        const { default: path } = await import('path');
        tmpPath = path.join(tmpDir, `mane_hd_${Date.now()}.jpg`);
        fs.writeFileSync(tmpPath, buffer);

        const result = await imgupscale.upscale(tmpPath, Number(scale));
        
        if (!result.success || !result.downloadUrls?.length) {
            throw new Error('Gagal melakukan upscale gambar.');
        }

        await mane.sendMessage(m.chat, { 
            image: { url: result.downloadUrls[0] }, 
            caption: `✅ Gambar berhasil ditingkatkan menjadi ${scale}x`
        }, { quoted: m });

    } catch (e) {
        m.reply(`Terjadi error: ${e.message}`);
    } finally {
        const fs = require('fs');
        if (tmpPath && fs.existsSync(tmpPath)) {
            fs.unlinkSync(tmpPath);
        }
    }
}
break;
case 'readviewonce':
case 'rvo': {
    if (!m.quoted) return m.reply('Balas pesan view once yang ingin dibaca');

    try {
        const quoted = m.quoted;
        const mime = (quoted.msg || quoted).mimetype || '';
        const captionAsli = quoted.msg?.caption || quoted.caption || quoted.text || 'Tidak ada caption';
        
        if (!mime) return m.reply('Jenis media tidak dikenali');
        
        
        let media;
        try {
            media = await mane.downloadAndSaveMediaMessage(quoted);
        } catch (downloadError) {
            console.error('Error downloading media:', downloadError);
            return m.reply('Gagal mengunduh media. Pastikan bot memiliki izin.');
        }

        let opsiPesan = { 
            quoted: m,
            caption: captionAsli ? captionAsli : 'Tidak ada caption',
        };

        if (/image/.test(mime)) {
            opsiPesan.image = { url: media };
        } else if (/video/.test(mime)) {
            opsiPesan.video = { url: media };
        } else if (/audio/.test(mime)) {
            opsiPesan.audio = { url: media };
            opsiPesan.mimetype = 'audio/mpeg';
            opsiPesan.ptt = false;
        } else if (/document/.test(mime)) {
            opsiPesan.document = { url: media };
            opsiPesan.mimetype = mime;
            opsiPesan.fileName = quoted.msg?.fileName || 'document';
        } else if (/sticker/.test(mime)) {
            opsiPesan.sticker = { url: media };
        } else {
            fs.unlinkSync(media); 
            return m.reply('Jenis media ini tidak didukung');
        }

        await mane.sendMessage(m.chat, opsiPesan);
        

        if (fs.existsSync(media)) {
            fs.unlinkSync(media);
        }
    } catch (error) {
        console.error('Gagal membaca view once:', error);
        m.reply('Gagal membaca pesan, coba lagi atau pastikan bot memiliki izin');
    }
}
break;
case 'qc': {
    if (!text) return m.reply("Mana Teksnya?");

    const pushname = m.pushName || m.sender.split('@')[0];

    await m.reply("⏳ Proses generate quote sticker . . .");

    let ppuser;
    try {
        ppuser = await mane.profilePictureUrl(m.sender, 'image');
    } catch (e) {
        console.log("Gagal mengambil foto profil, menggunakan gambar default. Error:", e);
        ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png';
    }

    try {
        const json = {
            "type": "quote",
            "format": "png",
            "backgroundColor": "#FFFFFF",
            "width": 512,
            "height": 768,
            "scale": 2,
            "messages": [{
                "entities": [],
                "avatar": true,
                "from": {
                    "id": 1,
                    "name": pushname,
                    "photo": {
                        "url": ppuser
                    }
                },
                "text": text,
                "replyMessage": {}
            }]
        };

        const response = await axios.post('https://bot.lyo.su/quote/generate', json, {
            headers: { 'Content-Type': 'application/json' }
        });

        const buffer = Buffer.from(response.data.result.image, 'base64');

        await mane.sendImageAsSticker(m.chat, buffer, m, {
            packname: global.packname || "Quote Sticker",
            author: global.author || "©ElainaBot"
        });

    } catch (error) {
        console.error("Error di perintah 'qc' saat generate/send sticker:", error);
        m.reply("Maaf, terjadi kesalahan saat membuat stiker quote. Silakan coba lagi.");
    }
}
break;
case 'sticker':
case 's': {
    const fs = require('fs');
    const path = require('path');
    const { exec } = require('child_process');

    const mediaSource = (m.mtype === 'imageMessage' || m.mtype === 'videoMessage') ? m : m.quoted;

    if (!mediaSource || !/image|video/.test(mediaSource.mtype)) {
        return m.reply(`Untuk membuat stiker, kirim gambar/video dengan caption *${prefix}sticker* atau balas media yang ada.\n\nUntuk memotong (crop), tambahkan rasio. Contoh: *${prefix}sticker 1:1*`);
    }

    const stickerMetadata = {
        packname: global.packname || 'Elaina Sticker',
        author: global.author || '© Mane'
    };

    let tempFilePath;

    try {
        const tmpDir = './tmp';
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }
        
        await mane.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
        tempFilePath = await mane.downloadAndSaveMediaMessage(mediaSource);
        const messageType = mediaSource.mtype;
        const ratioArg = args[0];

        if (!ratioArg) {
            const mediaBuffer = fs.readFileSync(tempFilePath);
            if (messageType === 'imageMessage') {
                await mane.sendImageAsSticker(m.chat, mediaBuffer, m, stickerMetadata);
            } else if (messageType === 'videoMessage') {
                const duration = mediaSource.message.videoMessage.seconds || 0;
                if (duration > 15) {
                    fs.unlinkSync(tempFilePath);
                    return m.reply('Maksimal durasi video untuk stiker adalah 15 detik!');
                }
                await mane.sendVideoAsSticker(m.chat, mediaBuffer, m, stickerMetadata);
            }
        } else {
            const ratios = {
                '1:1': { width: 1, height: 1 }, '4:3': { width: 4, height: 3 }, '4:5': { width: 4, height: 5 },
                '9:16': { width: 9, height: 16 }, '16:9': { width: 16, height: 9 }
            };

            if (!ratios[ratioArg]) {
                return m.reply(`Rasio tidak valid. Pilih dari: ${Object.keys(ratios).join(', ')}`);
            }
            const ratio = ratios[ratioArg];

            if (messageType === 'imageMessage') {
                const jimpImage = await jimp.read(tempFilePath);
                const { width, height } = jimpImage.bitmap;
                const targetRatio = ratio.width / ratio.height;
                let cropWidth = width, cropHeight = height;

                if (width / height > targetRatio) {
                    cropWidth = height * targetRatio;
                } else {
                    cropHeight = width / targetRatio;
                }
                
                const x = (width - cropWidth) / 2;
                const y = (height - cropHeight) / 2;
                
                jimpImage.crop(x, y, cropWidth, cropHeight);
                const buffer = await jimpImage.getBufferAsync(jimp.MIME_JPEG);
                await mane.sendImageAsSticker(m.chat, buffer, m, stickerMetadata);

            } else if (messageType === 'videoMessage') {
                const duration = mediaSource.message.videoMessage.seconds || 0;
                if (duration > 15) {
                    fs.unlinkSync(tempFilePath);
                    return m.reply('Maksimal durasi video untuk stiker adalah 15 detik!');
                }

                const outputPath = path.join(tmpDir, `output_${Date.now()}.mp4`);
                
                const { width, height } = await getVideoResolution(tempFilePath);
                const targetRatio = ratio.width / ratio.height;
                let cropWidth = width, cropHeight = height;

                if (width / height > targetRatio) {
                    cropWidth = Math.round(height * targetRatio);
                } else {
                    cropHeight = Math.round(width / targetRatio);
                }
                
                const x = Math.round((width - cropWidth) / 2);
                const y = Math.round((height - cropHeight) / 2);

                const ffmpegCommand = `ffmpeg -i "${tempFilePath}" -vf "crop=${cropWidth}:${cropHeight}:${x}:${y},scale=512:512" -an -y "${outputPath}"`;
                
                await new Promise((resolve, reject) => {
                    exec(ffmpegCommand, (err, stdout, stderr) => {
                        if (err) return reject(new Error(`Gagal memotong video: ${stderr || err.message}`));
                        resolve(true);
                    });
                });

                const buffer = fs.readFileSync(outputPath);
                await mane.sendVideoAsSticker(m.chat, buffer, m, stickerMetadata);
                if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
            }
        }
    } catch (err) {
        console.error('Sticker general error:', err);
        let errorMessage = `Terjadi kesalahan saat membuat stiker: ${err.message}`;
        if (err.message.toLowerCase().includes('ffmpeg') || err.message.toLowerCase().includes('ffprobe')) {
            errorMessage += '\n\n*Penyebab umum:* `ffmpeg` belum terpasang di sistem Anda. Silakan install terlebih dahulu.';
        }
        return m.reply(errorMessage);
    } finally {
        if (tempFilePath && fs.existsSync(tempFilePath)) {
            fs.unlinkSync(tempFilePath);
        }
    }
}
break;
case 'add': {
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");
    const groupMetadata = await mane.groupMetadata(m.chat).catch(e => {});
    if (!groupMetadata) return m.reply("Gagal mengambil data grup.");

    const participants = groupMetadata.participants;
    const senderIsAdmin = participants.find(p => p.id === m.sender)?.admin !== null;
    const botIsAdmin = participants.find(p => p.id === botNumber)?.admin !== null;

    if (!senderIsAdmin) return m.reply("Anda harus menjadi admin untuk menggunakan perintah ini.");
    if (!botIsAdmin) return m.reply("Jadikan bot sebagai admin terlebih dahulu.");

    let users = m.quoted ? m.quoted.sender : args.join(" ").replace(/[^0-9]/g, '');
    if (!users) return m.reply("Masukkan nomor telepon yang ingin ditambahkan.");

    const targetUser = users + "@s.whatsapp.net";

    try {
        const response = await mane.groupParticipantsUpdate(m.chat, [targetUser], "add");
        const code = response[0].status;

        if (code === '200') {
            await m.reply(`✅ Berhasil menambahkan ${"@" + users} ke dalam grup.`);
        } else if (code === '409') {
            await m.reply(`Maaf, ${"@" + users} sudah menjadi anggota grup ini.`);
        } else if (code === '403') {
            await m.reply(`Gagal menambahkan ${"@" + users} karena privasi.\nMengirimkan undangan grup...`);
            const inviteCode = await mane.groupInviteCode(m.chat);
            await mane.sendMessage(targetUser, {
                text: `Halo! Anda diundang untuk bergabung ke grup *${m.metadata.subject}*.\n\nKlik tautan di bawah untuk bergabung:\nhttps://chat.whatsapp.com/${inviteCode}`
            });
        } else {
             m.reply(`Gagal menambahkan anggota, status: ${code}`);
        }
    } catch (e) {
        console.error(e);
        m.reply("Terjadi kesalahan. Pastikan nomor yang Anda masukkan benar dan terdaftar di WhatsApp.");
    }
}
break;
case 'kick': {
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");
    if (!m.isAdmin) return m.reply("Maaf, fitur ini khusus untuk admin grup.");
    if (!m.isBotAdmin) return m.reply("Gagal, bot harus menjadi admin terlebih dahulu.");

    let targets = [];
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        targets = m.mentionedJid;
    } else if (m.quoted) {
        targets = [m.quoted.sender];
    } else {
        const number = args.join(' ').replace(/[^0-9]/g, '');
        if (!number) return m.reply("Target tidak valid. Silakan tag, balas pesan, atau ketik nomor anggota yang akan dikeluarkan.");
        targets = [number + "@s.whatsapp.net"];
    }

    if (targets.length === 0) return m.reply("Tidak ada target yang valid untuk dikeluarkan.");
    
    const participants = m.metadata.participants || [];
    const usersToKick = [];
    const skippedAdmins = [];

    for (const target of targets) {
        if (target === m.sender) continue;
        const targetIsAdmin = !!participants.find(p => p.jid === target)?.admin;
        
        if (targetIsAdmin) {
            skippedAdmins.push(target);
        } else {
            usersToKick.push(target);
        }
    }

    let replyText = "";

    if (skippedAdmins.length > 0) {
        const adminMentions = skippedAdmins.map(u => `@${u.split('@')[0]}`).join(', ');
        replyText += `⚠️ Gagal mengeluarkan ${adminMentions} karena mereka adalah admin.\n`;
    }

    if (usersToKick.length > 0) {
        try {
            await mane.groupParticipantsUpdate(m.chat, usersToKick, "remove");
            const kickedMentions = usersToKick.map(u => `@${u.split('@')[0]}`).join(', ');
            replyText += `✅ Berhasil mengeluarkan ${kickedMentions}.`;
        } catch (e) {
            console.error(e);
            replyText += `❌ Terjadi kesalahan saat mencoba mengeluarkan anggota.`;
        }
    }

    if (!replyText) {
        replyText = "Tidak ada tindakan yang dilakukan. Target mungkin adalah diri sendiri atau admin.";
    }

    await mane.sendMessage(m.chat, {
        text: replyText.trim(),
        mentions: [...skippedAdmins, ...usersToKick]
    }, { quoted: m });
}
break;
case 'hidetag':
case 'h':
case 'tag': {
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");
    if (!m.isAdmin && !isOwner) return m.reply('Hanya admin dan owner yang bisa menggunakan perintah ini.');

    if (!text && !m.quoted) return m.reply(`Masukkan teks yang ingin ditag\nContoh: ${prefix}hidetag Hai semua`);
    
    const moment = require('moment-timezone');
    const currentTime = moment().tz('Asia/Jakarta').format('HH:mm:ss • DD/MM/YYYY');
    
    const textToSend = text ? text : (m.quoted ? m.quoted.text : '');
    
    const participants = m.metadata.participants;
    const allParticipantIds = participants.map(a => a.id);
    
    const formattedMessage = 
`*「 PESAN HIDETAG 」*

*Dari*: @${m.sender.split('@')[0]}
*Isi Pesan*: ${textToSend}`;

    await mane.sendMessage(m.chat, { 
        text: formattedMessage,
        mentions: allParticipantIds, 
        contextInfo: {
            mentionedJid: allParticipantIds,
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: false,
                title: 'HIDETAG NOTIFICATION',
                body: `Waktu: ${currentTime}`,
                thumbnailUrl: 'https://files.catbox.moe/wvooxl.jpg',
                mediaType: 1,
                thumbnailWidth: 60,
                thumbnailHeight: 60,
                sourceUrl: ''
            }
        }
    });
}
break;
    case 'play': {
    if (!text) {
        return m.reply('Perintah salah. Silakan masukkan judul lagu.\n\n*Contoh:*\n.play2 judul lagu');
    }

    await m.reply('✨ Tunggu sebentar, sedang mencari dan mengunduh lagu...');

    const initialApiUrl = `https://izumiiiiiiii.dpdns.org/downloader/play?query=${encodeURIComponent(text)}`;

    try {
        const { data: apiResponse } = await axios.get(initialApiUrl);

        if (typeof apiResponse !== 'object' || !apiResponse.result || !apiResponse.result.downloads) {
            console.error('API Response tidak valid:', apiResponse);
            return m.reply('Gagal memproses respon dari API. Format data tidak sesuai.');
        }

        const downloadUrl = apiResponse.result.downloads;

        const { data: audioData } = await axios.get(downloadUrl, {
            responseType: 'arraybuffer'
        });

        const audioBuffer = Buffer.from(audioData);

        await mane.sendMessage(m.chat, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            fileName: `${text}.mp3`,
            ptt: false
        }, { quoted: m });

    } catch (e) {
        console.error('Error pada fitur play2 (alur 2 langkah):', e);
        m.reply('Terjadi kesalahan. API mungkin tidak menemukan lagu atau server download sedang bermasalah.');
    }
    break;
}
case 'tiktok':
case 'tt':
case 'ttdl': {
    const axios = require('axios');
    const cheerio = require('cheerio');
    const FormData = require('form-data');
    const moment = require('moment-timezone');
    const { exec } = require('child_process');
    const fs = require('fs');
    const path = require('path');

    async function tiktokV1(query) {
        const encodedParams = new URLSearchParams();
        encodedParams.set('url', query);
        encodedParams.set('hd', '1');

        const { data } = await axios.post('https://tikwm.com/api/', encodedParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Cookie': 'current_language=en',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
            }
        });
        return data;
    }

    async function tiktokV2(query) {
        const form = new FormData();
        form.append('q', query);

        const { data } = await axios.post('https://savetik.co/api/ajaxSearch', form, {
            headers: {
                ...form.getHeaders(),
                'Accept': '*/*',
                'Origin': 'https://savetik.co',
                'Referer': 'https://savetik.co/en2',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
                'X-Requested-With': 'XMLHttpRequest'
            }
        });

        const rawHtml = data.data;
        const $ = cheerio.load(rawHtml);
        const title = $('.thumbnail .content h3').text().trim();
        const thumbnail = $('.thumbnail .image-tik img').attr('src');
        const video_url = $('video#vid').attr('data-src');

        const slide_images = [];
        $('.photo-list .download-box li').each((_, el) => {
            const imgSrc = $(el).find('.download-items__thumb img').attr('src');
            if (imgSrc) slide_images.push(imgSrc);
        });

        return { title, thumbnail, video_url, slide_images };
    }

    if (!text) return m.reply('Masukkan URL TikTok yang valid.\nContoh: .tiktok https://vt.tiktok.com/xxxxxx');

    await m.reply('Mohon tunggu, sedang memproses dan mengkonversi video...');

    try {
        let res;
        let images = [];

        const dataV1 = await tiktokV1(text);
        if (dataV1?.data) {
            const d = dataV1.data;
            if (Array.isArray(d.images) && d.images.length > 0) {
                images = d.images;
            } else if (Array.isArray(d.image_post) && d.image_post.length > 0) {
                images = d.image_post;
            }
            res = {
                title: d.title,
                region: d.region,
                duration: d.duration,
                create_time: d.create_time,
                play_count: d.play_count,
                digg_count: d.digg_count,
                comment_count: d.comment_count,
                share_count: d.share_count,
                download_count: d.download_count,
                author: {
                    unique_id: d.author?.unique_id,
                    nickname: d.author?.nickname
                },
                music_info: {
                    title: d.music_info?.title,
                    author: d.music_info?.author
                },
                cover: d.cover,
                play: d.play,
                hdplay: d.hdplay,
                wmplay: d.wmplay
            };
        }

        const dataV2 = await tiktokV2(text);
        if ((!res?.play && images.length === 0) && dataV2.video_url) {
            res = res || { play: dataV2.video_url, title: dataV2.title };
        }
        if (images.length === 0 && Array.isArray(dataV2.slide_images) && dataV2.slide_images.length > 0) {
            images = dataV2.slide_images;
        }

        if (images.length > 0) {
            await m.reply(`Terdeteksi ${images.length} gambar, sedang mengirim...`);
            for (const img of images) {
                await mane.sendMessage(m.chat, {
                    image: { url: img },
                    caption: res.title || ''
                }, { quoted: m });
            }
            return;
        }

        const time = res.create_time ?
            moment.unix(res.create_time).tz('Asia/Jakarta').format('dddd, D MMMM YYYY [pukul] HH:mm:ss') :
            '-';

        const caption = `*Video TikTok Info*
*Judul:* ${res.title || '-'}
*Region:* ${res.region || 'N/A'}
*Durasi:* ${res.duration || '-'} detik
*Waktu Upload:* ${time}
*Author:* ${res.author?.nickname || '-'}`;

        const videoUrl = res.hdplay || res.play || res.wmplay;
        if (videoUrl) {
            const tempDir = './tmp';
            if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
            const inputPath = path.join(tempDir, `tiktok_in_${Date.now()}.mp4`);
            const outputPath = path.join(tempDir, `tiktok_out_${Date.now()}.mp4`);

            try {
                const response = await axios({
                    url: videoUrl,
                    method: 'GET',
                    responseType: 'stream'
                });
                const writer = fs.createWriteStream(inputPath);
                response.data.pipe(writer);
                await new Promise((resolve, reject) => {
                    writer.on('finish', resolve);
                    writer.on('error', reject);
                });

                await new Promise((resolve, reject) => {
                    exec(`ffmpeg -i ${inputPath} -c:v libx264 -c:a aac -pix_fmt yuv420p -movflags +faststart ${outputPath}`, (error, stdout, stderr) => {
                        if (error) {
                            console.error('FFmpeg Error:', stderr);
                            return reject(new Error('Gagal mengkonversi video. Pastikan FFmpeg terpasang.'));
                        }
                        resolve(true);
                    });
                });

                const videoBuffer = fs.readFileSync(outputPath);
                await mane.sendMessage(m.chat, { 
                    video: videoBuffer, 
                    caption: caption, 
                    mimetype: 'video/mp4' 
                }, { quoted: m });

            } finally {
                if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
                if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
            }
        } else {
            m.reply("Maaf, gagal menemukan link video yang valid dari URL tersebut.");
        }
    } catch (e) {
        console.error(e);
        m.reply(`Terjadi kesalahan saat memproses permintaan: ${e.message}`);
    }
}
break;
case 'bratvid': {
    await mane.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    const text = args.join(' ');
    if (!text) {
        m.reply('Contoh: .bratv halo dunia');
        await mane.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return; 
    }

    try {
        const apiUrl = `https://api.ypnk.dpdns.org/api/video/bratv?text=${encodeURIComponent(text)}`;
        
        const response = await axios.get(apiUrl, {
            responseType: 'arraybuffer'
        });
        
        const videoBuffer = Buffer.from(response.data);

        const sticker = new Sticker(videoBuffer, {
            pack: 'BRAT Video',
            author: 'Elaina Bot',
            type: StickerTypes.CROPPED, 
            quality: 50
        });
        
        await mane.sendMessage(m.chat, { 
            sticker: await sticker.toBuffer() 
        }, { quoted: m });

        await mane.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (e) {
        console.error("Error pada perintah bratv:", e);
        await mane.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        m.reply('Gagal membuat stiker video. Kemungkinan API sedang bermasalah.');
    }
}
break;
case 'listjpmgc': {
    if (!isOwner) return m.reply(mess.owner);

    try {
        await mane.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

        const getGroups = await mane.groupFetchAllParticipating();
        const groups = Object.values(getGroups);

        if (groups.length === 0) {
            return m.reply("Bot tidak tergabung dalam grup manapun.");
        }

        let groupListText = "*DAFTAR GRUP BOT*\n\n";
        groups.forEach((group, index) => {
            groupListText += `${index + 1}. *${group.subject}*\n`;
        });
        
        groupListText += "\nUntuk mengirim pesan, gunakan `.jpm nomor,pesan`";
        await m.reply(groupListText);
        
    } catch (e) {
        console.error("Error pada listjpmgc:", e);
        m.reply("Terjadi kesalahan saat mengambil daftar grup.");
    }
}
break;

case 'jpm': {
    if (!isOwner) return m.reply(mess.owner);

    try {
        const getGroups = await mane.groupFetchAllParticipating();
        const allGroupJids = Object.values(getGroups).map(g => g.id);

        if (allGroupJids.length === 0) {
            return m.reply("Bot tidak tergabung dalam grup manapun.");
        }

        const textArgs = args.join(' ');
        const parts = textArgs.split(',');

        if (parts.length < 2) {
            return m.reply("Format salah. Gunakan `.jpm nomor_grup,pesan_anda`\n*Contoh:*\n.jpm 1,3-5,Halo semua, ini info penting.");
        }

        const selectors = [];
        const messageParts = [];
        let messageStarted = false;

        const isSelector = (str) => /^\d+$/.test(str) || /^\d+-\d+$/.test(str);

        for (const part of parts) {
            const trimmedPart = part.trim();
            if (!messageStarted && isSelector(trimmedPart)) {
                selectors.push(trimmedPart);
            } else {
                messageStarted = true;
                messageParts.push(part);
            }
        }

        const messageText = messageParts.join(',').trim();

        if (!messageText) {
            return m.reply("Pesan tidak boleh kosong.");
        }
        
        const selectedJids = [];
        for (const selector of selectors) {
            if (selector.includes('-')) {
                const [start, end] = selector.split('-').map(Number);
                if (!isNaN(start) && !isNaN(end) && start <= end) {
                    for (let i = start; i <= end; i++) {
                        if (allGroupJids[i - 1]) {
                            selectedJids.push(allGroupJids[i - 1]);
                        }
                    }
                }
            } else {
                const index = Number(selector);
                if (!isNaN(index) && allGroupJids[index - 1]) {
                    selectedJids.push(allGroupJids[index - 1]);
                }
            }
        }

        const uniqueJids = [...new Set(selectedJids)];

        if (uniqueJids.length === 0) {
            return m.reply("Tidak ada grup valid yang dipilih. Jalankan `.listjpmgc` untuk melihat nomor yang benar.");
        }

        let sentCount = 0;
        let failedCount = 0;
        
        m.reply(`✅ Pengiriman pesan ke ${uniqueJids.length} grup telah dimulai...`);

        for (const jid of uniqueJids) {
            try {
                await mane.sendMessage(jid, { text: messageText });
                sentCount++;
            } catch (e) {
                console.error(`Gagal mengirim ke ${jid}:`, e);
                failedCount++;
            }
            await sleep(15000); 
        }

        await m.reply(`*PENGIRIMAN SELESAI*\n\n- *Berhasil terkirim:* ${sentCount} grup\n- *Gagal terkirim:* ${failedCount} grup`);

    } catch (e) {
        console.error("Error pada fitur jpm:", e);
        m.reply("Terjadi kesalahan sistem saat menjalankan perintah jpm.");
    }
}
break;
case 'smeme': {
    if (!m.quoted) return m.reply(`Balas gambar dengan perintah:\n${prefix + command} <teks>`);
    if (!text) return m.reply(`Teks tidak boleh kosong.\nContoh:\n${prefix}smeme teks atas\n${prefix}smeme teks atas|teks bawah\n${prefix}smeme |teks bawah`);

    const { Sticker } = require('wa-sticker-formatter');
    const FormData = require('form-data');
    const axios = require('axios');
    const fs = require('fs');
    const path = require('path');

    async function uploadImage(filePath) {
        try {
            const form = new FormData();
            form.append('files[]', fs.createReadStream(filePath));
            
            const { data } = await axios.post('https://uguu.se/upload', form, {
                headers: form.getHeaders()
            });
            return data.files[0].url;
        } catch (err) {
            throw new Error(`Gagal mengunggah gambar: ${err.message}`);
        }
    }

    async function createStickerFromUrl(imageUrl) {
        const stickerMetadata = {
            type: "full",
            pack: global.packname || "Seiha Sticker",
            author: global.author || "© SEIHA",
            quality: 100
        };
        return new Sticker(imageUrl, stickerMetadata).toBuffer();
    }

    let [topText, bottomText] = text.split('|');
    let quotedMsg = m.quoted ? m.quoted : m;
    let mime = (quotedMsg.msg || quotedMsg).mimetype || "";

    if (!mime.startsWith('image/')) return m.reply("❌ Perintah ini hanya bisa digunakan untuk membalas gambar!");

    await mane.sendMessage(m.chat, { react: { text: '🖼️', key: m.key } });

    let tempFilePath; 

    try {

        let mediaBuffer;
        if (quotedMsg.msg) {
            mediaBuffer = await downloadMediaMessage(quotedMsg, "buffer", {});
        } else {
            mediaBuffer = await mane.downloadMediaMessage(quotedMsg);
        }

        let fileExtension = mime.split('/')[1] || "png";
        tempFilePath = path.join(__dirname, `temp_smeme_${Date.now()}.${fileExtension}`); 
        

        fs.writeFileSync(tempFilePath, mediaBuffer);

        let imageUrl = await uploadImage(tempFilePath);
        
        let memeApiUrl = `https://api.memegen.link/images/custom/${encodeURIComponent(topText || " ")}/${encodeURIComponent(bottomText || " ")}.png?background=${imageUrl}`;
        
        let stickerBuffer = await createStickerFromUrl(memeApiUrl);

        await mane.sendMessage(m.chat, { sticker: stickerBuffer }, { quoted: m });
        await mane.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
        console.error(err);
        m.reply(`❌ Terjadi kesalahan saat membuat meme: ${err.message}`);
    } finally {

        if (tempFilePath && fs.existsSync(tempFilePath)) {
            fs.unlinkSync(tempFilePath);
        }
    }
}
break;
case 'upapikey': {
        if (!isCreator) return m.reply("Perintah ini hanya untuk Creator Bot.");
        const text = args.join(" ");
        const parts = text.split(',');
        if (parts.length !== 3) {
          return m.reply("Format salah.\nGunakan: .upapikey domain,ptla,ptlc\n\nContoh:\n.upapikey https://panel.domain.com,ptla_xxx,ptlc_xxx");
        }
        const [newDomain, newPtla, newPtlc] = parts.map(p => p.trim());
        if (!newDomain.startsWith('http')) {
          return m.reply("Peringatan: Format domain tidak valid. Harap gunakan 'http://' atau 'https://'.");
        }
        if (!newPtla.startsWith('ptla_')) {
          return m.reply("Peringatan: API Key (PTLA) tidak valid. Kunci harus diawali dengan 'ptla_'.");
        }
        if (!newPtlc.startsWith('ptlc_')) {
          return m.reply("Peringatan: Client Key (PTLC) tidak valid. Kunci harus diawali dengan 'ptlc_'.");
        }
        global.domain = newDomain;
        global.apikey = newPtla;
        global.capikey = newPtlc;
        const updates = [
          { key: 'domain', value: newDomain },
          { key: 'apikey', value: newPtla },
          { key: 'capikey', value: newPtlc }
        ];
        const success = await updateApiKeys(updates);
        if (success) {
          m.reply("✅ Berhasil memperbarui API Key untuk Server 1.");
        } else {
          m.reply("❌ Gagal memperbarui API Key. Silakan cek konsol untuk error.");
        }
      }
      break;
      case 'upapikey2': {
        if (!isCreator) return m.reply("Perintah ini hanya untuk Creator Bot.");
        const text = args.join(" ");
        const parts = text.split(',');
        if (parts.length !== 3) {
          return m.reply("Format salah.\nGunakan: .upapikey2 domain,ptla,ptlc\n\nContoh:\n.upapikey2 https://panel.domain.com,ptla_xxx,ptlc_xxx");
        }
        const [newDomain, newPtla, newPtlc] = parts.map(p => p.trim());
        if (!newDomain.startsWith('http')) {
          return m.reply("Peringatan: Format domain tidak valid. Harap gunakan 'http://' atau 'https://'.");
        }
        if (!newPtla.startsWith('ptla_')) {
          return m.reply("Peringatan: API Key (PTLA) tidak valid. Kunci harus diawali dengan 'ptla_'.");
        }
        if (!newPtlc.startsWith('ptlc_')) {
          return m.reply("Peringatan: Client Key (PTLC) tidak valid. Kunci harus diawali dengan 'ptlc_'.");
        }
        global.domainv2 = newDomain;
        global.apikeyv2 = newPtla;
        global.capikeyv2 = newPtlc;
        const updates = [
          { key: 'domainv2', value: newDomain },
          { key: 'apikeyv2', value: newPtla },
          { key: 'capikeyv2', value: newPtlc }
        ];
        const success = await updateApiKeys(updates);
        if (success) {
          m.reply("✅ Berhasil memperbarui API Key untuk Server 2.");
        } else {
          m.reply("❌ Gagal memperbarui API Key. Silakan cek konsol untuk error.");
        }
      }
      break;
      case 'delapikey': {
        if (!isCreator) return m.reply("Perintah ini hanya untuk Creator Bot.");

        global.domain = '';
        global.apikey = '';
        global.capikey = '';

        const updates = [
          { key: 'domain', value: '' },
          { key: 'apikey', value: '' },
          { key: 'capikey', value: '' }
        ];

        const success = await updateApiKeys(updates);

        if (success) {
          m.reply("✅ Berhasil menghapus API Key untuk Server 1.");
        } else {
          m.reply("❌ Gagal menghapus API Key. Silakan cek konsol untuk error.");
        }
      }
      break;

      case 'delapikey2': {
        if (!isCreator) return m.reply("Perintah ini hanya untuk Creator Bot.");

        global.domainv2 = '';
        global.apikeyv2 = '';
        global.capikeyv2 = '';

        const updates = [
          { key: 'domainv2', value: '' },
          { key: 'apikeyv2', value: '' },
          { key: 'capikeyv2', value: '' }
        ];

        const success = await updateApiKeys(updates);

        if (success) {
          m.reply("✅ Berhasil menghapus API Key untuk Server 2.");
        } else {
          m.reply("❌ Gagal menghapus API Key. Silakan cek konsol untuk error.");
        }
      }
      break;


case 'addprem':
case 'addpremium': {
    if (!isOwner) return m.reply(mess.owner);
    let user;
    if (m.quoted) {
        user = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        const validJids = m.mentionedJid.filter(jid => jid.endsWith('@s.whatsapp.net'));
        if (validJids.length > 0) {
            user = validJids[0].split('@')[0];
        } else {
            return m.reply("replay oi");
        }
    } else {
        user = args[0]?.replace(/[^0-9]/g, '');
    }

    if (!user) return m.reply("Target tidak ditemukan.\n\n*Cara Penggunaan:*\n1. Balas (reply) pesan target.\n2. Tag pengguna (@user).\n3. Ketik nomor telepon (contoh: 628xxxx).");

    if (global.premiumusers.includes(user)) return m.reply(`Nomor ${user} sudah terdaftar sebagai pengguna premium untuk Server 1.`);

    global.premiumusers.push(user);
    savePremiumUsers(global.premiumusers, premiumUsersFilePath);
    await m.reply(`✅ Berhasil! Nomor ${user} sekarang memiliki akses premium permanen untuk Server 1.`);
}
break;

case 'delprem':
case 'delpremium': {
    if (!isOwner) return m.reply(mess.owner);
    let user;
    if (m.quoted) {
        user = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        const validJids = m.mentionedJid.filter(jid => jid.endsWith('@s.whatsapp.net'));
        if (validJids.length > 0) {
            user = validJids[0].split('@')[0];
        } else {
            return m.reply("replay oi");
        }
    } else {
        user = args[0]?.replace(/[^0-9]/g, '');
    }

    if (!user) return m.reply("Target tidak ditemukan.\n\n*Cara Penggunaan:*\n1. Balas (reply) pesan target.\n2. Tag pengguna (@user).\n3. Ketik nomor telepon (contoh: 628xxxx).");

    const index = global.premiumusers.indexOf(user);
    if (index === -1) return m.reply(`Nomor ${user} tidak ditemukan dalam daftar premium Server 1.`);

    global.premiumusers.splice(index, 1);
    savePremiumUsers(global.premiumusers, premiumUsersFilePath);
    await m.reply(`✅ Berhasil! Akses premium Server 1 untuk nomor ${user} telah dihapus.`);
}
break;

case 'addpremv2':
case 'addpremiumv2': {
    if (!isOwner) return m.reply(mess.owner);
    let user;
    if (m.quoted) {
        user = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        const validJids = m.mentionedJid.filter(jid => jid.endsWith('@s.whatsapp.net'));
        if (validJids.length > 0) {
            user = validJids[0].split('@')[0];
        } else {
            return m.reply("replay oi");
        }
    } else {
        user = args[0]?.replace(/[^0-9]/g, '');
    }

    if (!user) return m.reply("Target tidak ditemukan.\n\n*Cara Penggunaan:*\n1. Balas (reply) pesan target.\n2. Tag pengguna (@user).\n3. Ketik nomor telepon (contoh: 628xxxx).");

    if (global.premiumusersv2.includes(user)) return m.reply(`Nomor ${user} sudah terdaftar sebagai pengguna premium untuk Server 2.`);

    global.premiumusersv2.push(user);
    savePremiumUsers(global.premiumusersv2, premiumUsersV2FilePath);
    await m.reply(`✅ Berhasil! Nomor ${user} sekarang memiliki akses premium permanen untuk Server 2.`);
}
break;
case 'delpremv2':
case 'delpremiumv2': {
    if (!isOwner) return m.reply(mess.owner);
    let user;
    if (m.quoted) {
        user = m.quoted.sender.split('@')[0];
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        const validJids = m.mentionedJid.filter(jid => jid.endsWith('@s.whatsapp.net'));
        if (validJids.length > 0) {
            user = validJids[0].split('@')[0];
        } else {
            return m.reply("reply oi");
        }
    } else {
        user = args[0]?.replace(/[^0-9]/g, '');
    }
    
    if (!user) return m.reply("Target tidak ditemukan.\n\n*Cara Penggunaan:*\n1. Balas (reply) pesan target.\n2. Tag pengguna (@user).\n3. Ketik nomor telepon (contoh: 628xxxx).");

    const index = global.premiumusersv2.indexOf(user);
    if (index === -1) return m.reply(`Nomor ${user} tidak ditemukan dalam daftar premium Server 2.`);

    global.premiumusersv2.splice(index, 1);
    savePremiumUsers(global.premiumusersv2, premiumUsersV2FilePath);
    await m.reply(`✅ Berhasil! Akses premium Server 2 untuk nomor ${user} telah dihapus.`);
}
break;

case 'done':
case 'd': {
    if (!isOwner) return m.reply(mess.owner);

    const s = text.split(',');
    
    if (s.length < 3) {
        return m.reply(`*Format salah!* Mohon masukkan semua detail.\n\n*Penggunaan:*\n.done barang,nominal,metode\n\n*Contoh:*\n.done Panel 1GB,10000,Qris`);
    }

    let [barang, nominal, metode] = s.map(part => part.trim());

    if (isNaN(nominal)) {
        return m.reply(`*Format salah!* Nominal harus berupa angka.\n\n*Contoh:*\n.done Panel 1GB,10000,Qris`);
    }

    const text_done = 
`「 *TRANSAKSI BERHASIL* 」

*📦 Barang :* ${barang}
*💸 Nominal :* ${toRupiah(nominal)}
*💳 Metode :* ${metode}
*📆 Tanggal :* ${tanggal(Date.now())}
*✨ Status :* Berhasil
*⚠️ Semua Transaksi bersifat Final (No Refund)!*

*Terima Kasih Telah Berbelanja!*

*Owner:*
${global.waMe || 'wa.me/owner_number'}

*Channel Informasi:*
${global.linkch || 'Link Channel Anda'}

*Channel Testimoni:*
${global.chtesti || 'Link Channel Testi Anda'}`;

    await mane.relayMessage(m.chat, {
        requestPaymentMessage: {
            currencyCodeIso4217: 'IDR',
            amount1000: Number(nominal) * 1000,
            requestFrom: m.sender,
            noteMessage: {
                extendedTextMessage: {
                    text: text_done,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: false,
                            thumbnailUrl: '',
                            mediaType: 1,
                            renderLargerThumbnail: true,
                            title: 'TRANSAKSI SUKSES',
                            body: `Oleh: ${pushname}`
                        }
                    }
                }
            }
        }
    }, {});
}
break;
case 'proses': {
    if (!isOwner) return m.reply(mess.owner);
    if (!m.quoted) return m.reply('Reply pesanan yang akan diproses');

    const moment = require('moment-timezone');

    const pesananText = m.quoted.text;
    const customerJid = m.quoted.sender;
    const customerNumber = customerJid.split('@')[0];
    const adminJid = m.sender;
    
    const jam = moment().tz('Asia/Jakarta').format('HH:mm:ss');
    const tgl = tanggal(Date.now());

    const prosesText = `
    ── 「 *DETAIL PESANAN* 」 ──

🔁 *Status :* Transaksi Pending
📥 *Pesanan Dari :* @${customerNumber}⁩
🗓️ *Tanggal :* ${tgl}
🕒 *Jam :* ${jam}
📦 *Status Pesanan :* Diproses ⏳
📝 *Catatan Pesanan  :* _PESANAN ANDA SEGERA DI PROSES SELLER HARAP TUNGGU SEBENTAR . . ._


_*Tunggu Sebentar, Orderan Kamu Sedang Diproses Oleh Admin* @${m.sender.split('@')[0]}_
    `;

    const mentionedJids = [customerJid, adminJid];

    await mane.sendMessage(m.chat, {
        text: prosesText.trim(),
        mentions: mentionedJids
    }, { quoted: fakeStatus }); 
}
break;
case 'dana': {
    if (!global.dana || !global.qrisdana) {
        return m.reply("Pengaturan DANA (global.dana) dan QRIS (global.qrisdana) belum diatur di file settings.js");
    }

    const danaText = `
╭─── • *PEMBAYARAN DANA*
│
│ ◈ *Nomor:* ${global.dana}
│
│ 💬 _Silakan lakukan pembayaran dan kirimkan bukti transaksi._
│
╰──────────────────⪨
    `.trim();

    try {
        const interactiveMessage = {
            body: { text: danaText },
            footer: { text: '© Elaina Payment' },
            header: {
                title: "💎 DETAIL PEMBAYARAN",
                hasMediaAttachment: false
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Tampilkan QRIS",
                            id: `${prefix}qrisdana`
                        })
                    },
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Salin Nomor",
                            copy_code: global.dana
                        })
                    }
                ]
            }
        };

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: interactiveMessage
                }
            }
        }, {
            quoted: fakeStatus
        });

        await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (err) {
        console.error("Error pada fitur dana:", err);
        m.reply("Gagal menampilkan menu pembayaran ovo. Silakan coba lagi.");
    }
}
break;

case 'qrisdana': {
    if (!global.qrisdana) {
        return m.reply("Pengaturan QRIS (global.qrisovo) belum diatur di file settings.js.");
    }

    await mane.sendMessage(m.chat, {
        image: { url: global.qrisdana },
        caption: `───━───────━─── 
*QRIS DANA* 💳
───━───────━───
_*Silahkan scan metode qris di atas untuk melakukan pembayaran ✅*_
> _WAJIB SS BUKTI TRANSAKSI !!_`
    }, { quoted: fakeStatus });
}
break;

case 'ovo': {
    if (!global.ovo || !global.qrisovo) {
        return m.reply("Pengaturan ovo (global.ovo) dan QRIS (global.qrisovo) belum diatur di file settings.js");
    }

    const ovoText = `
╭─── • *PEMBAYARAN OVO*
│
│ ◈ *Nomor:* ${global.ovo}
│
│ 💬 _Silakan lakukan pembayaran dan kirimkan bukti transaksi._
│
╰──────────────────⪨
    `.trim();

    try {
        const interactiveMessage = {
            body: { text: ovoText },
            footer: { text: '© Elaina Payment' },
            header: {
                title: "💎 DETAIL PEMBAYARAN",
                hasMediaAttachment: false
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Tampilkan QRIS",
                            id: `${prefix}qrisovo`
                        })
                    },
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Salin Nomor",
                            copy_code: global.ovo
                        })
                    }
                ]
            }
        };

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: interactiveMessage
                }
            }
        }, {
            quoted: fakeStatus
        });

        await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (err) {
        console.error("Error pada fitur ovo:", err);
        m.reply("Gagal menampilkan menu pembayaran ovo. Silakan coba lagi.");
    }
}
break;

case 'qrisovo': {
    if (!global.qrisovo) {
        return m.reply("Pengaturan QRIS (global.qrisovo) belum diatur di file settings.js.");
    }

    await mane.sendMessage(m.chat, {
        image: { url: global.qrisovo },
        caption: `───━───────━─── 
*QRIS OVO* 💳
───━───────━───
_*Silahkan scan metode qris di atas untuk melakukan pembayaran ✅*_
> _WAJIB SS BUKTI TRANSAKSI !!_"`
    }, { quoted: fakeStatus });
}
break;

case 'gopay': {
    if (!global.gopay || !global.qrisgopay) {
        return m.reply("Pengaturan gopay (global.gopay) dan QRIS (global.qrisgopay) belum diatur di file settings.js");
    }

    const gopayText = `
╭─── • *PEMBAYARAN GOPAY*
│
│ ◈ *Nomor:* ${global.gopay}
│
│ 💬 _Silakan lakukan pembayaran dan kirimkan bukti transaksi._
│
╰──────────────────⪨
    `.trim();

    try {
        const interactiveMessage = {
            body: { text: gopayText },
            footer: { text: '© Elaina Payment' },
            header: {
                title: "💎 DETAIL PEMBAYARAN",
                hasMediaAttachment: false
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Tampilkan QRIS",
                            id: `${prefix}qrisgopay`
                        })
                    },
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "Salin Nomor",
                            copy_code: global.gopay
                        })
                    }
                ]
            }
        };

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: interactiveMessage
                }
            }
        }, {
            quoted: fakeStatus
        });

        await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (err) {
        console.error("Error pada fitur gopay:", err);
        m.reply("Gagal menampilkan menu pembayaran gopay. Silakan coba lagi.");
    }
}
break;

case 'qrisgopay': {
    if (!global.qrisgopay) {
        return m.reply("Pengaturan QRIS (global.qrisgopay) belum diatur di file settings.js.");
    }

    await mane.sendMessage(m.chat, {
        image: { url: global.qrisgopay },
        caption: `───━───────━─── 
*QRIS GOPAY* 💳
───━───────━───
_*Silahkan scan metode qris di atas untuk melakukan pembayaran ✅*_
> _WAJIB SS BUKTI TRANSAKSI !!_`
    }, { quoted: fakeStatus });
}
break;

case 'qris': {
    if (!global.qrisallpayment) {
        return m.reply("Pengaturan QRIS (global.qrisgopay) belum diatur di file settings.js.");
    }

    await mane.sendMessage(m.chat, {
        image: { url: global.qrisallpayment },
        caption: `───━───────━─── 
*QRIS ALL PAYMENT* 💳
───━───────━───
_*Silahkan scan metode qris di atas untuk melakukan pembayaran ✅*_
> _WAJIB SS BUKTI TRANSAKSI !!_`
    }, { quoted: fakeStatus });
}
break;
case "pushkontak": {
    if (!isOwner) return m.reply(mess.owner);
    if (!text) return m.reply('Contoh: .pushkontak Halo semua, ini pesan penting!');
    
    try {
        const meta = await mane.groupFetchAllParticipating();
        const groups = Object.values(meta);
        global.textpushkontak = text;
        let list = [];

        for (let group of groups) {
            list.push({
                title: group.subject,
                id: `${prefix}respushkontak ${group.id}`,
                description: `${group.participants.length} Anggota`
            });
        }

        const paramsJson = {
            title: 'Pilih Grup Target',
            sections: [{
                title: 'DAFTAR GRUP',
                highlight_label: `${groups.length} Grup Ditemukan`,
                rows: list
            }]
        };
        
        const interactiveMessage = {
            body: { text: "Silakan pilih grup yang akan menjadi target Push Kontak." },
            footer: { text: `© ${global.botname}` },
            header: { title: "MENU PUSHKONTAK", hasMediaAttachment: false },
            nativeFlowMessage: {
                buttons: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify(paramsJson)
                }]
            }
        };

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: interactiveMessage
                }
            }
        }, { quoted: m });

        await mane.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        
    } catch (e) {
        console.error(e);
        m.reply("Terjadi kesalahan saat mengambil daftar grup.");
    }
}
break;

case "respushkontak": {
    if (!isOwner) return (mess.owner)
    if (!text) return m.reply("ID Grup tidak ditemukan.");
    if (!global.textpushkontak) return m.reply("Pesan pushkontak tidak ditemukan. Silakan mulai ulang dengan perintah .pushkontak");

    const idgc = text;
    const teks = global.textpushkontak;
    
    try {
        const data = await mane.groupMetadata(idgc);
        const members = data.participants.map(p => p.id);
        
        await m.reply(`Memulai *Push Kontak* ke dalam grup *${data.subject}* (${members.length} anggota)...`);
        let sentCount = 0;

        for (let mem of members) {
            if (mem === botNumber || global.owner.includes(mem.split("@")[0])) continue;
            console.log(`Mengirim pesan pushkontak ke: ${mem}`); 
            await mane.sendMessage(mem, { text: teks }, { quoted: pushkontakFakeReply });
            sentCount++;
            const randomDelay = Math.floor(Math.random() * (global.maxDelayPushkontak - global.minDelayPushkontak + 1)) + global.minDelayPushkontak;
            await sleep(randomDelay);
        }

        delete global.textpushkontak;
        await m.reply(`*✅ Push Kontak Selesai*\nTotal pesan berhasil terkirim: ${sentCount} anggota.`);
        
    } catch (e) {
        console.error(e);
        delete global.textpushkontak;
        m.reply(`Gagal melakukan push kontak ke grup ${idgc}. Mungkin bot bukan anggota grup tersebut.`);
    }
}
break;

case "pushkontak2": {
    if (!isOwner) return m.reply(mess.owner);
    if (!m.isGroup) return m.reply(mess.group);
    if (!text) return m.reply('Contoh: .pushkontak2 Halo semua, ini pesan penting!');
    
    const teks = text;
    const data = await mane.groupMetadata(m.chat);
    const members = data.participants.map(p => p.id);
    
    await m.reply(`Memulai *Push Kontak* ke *${members.length}* anggota di grup ini...`);
    let sentCount = 0;

    for (let mem of members) {
        if (mem === botNumber || global.owner.includes(mem.split("@")[0])) continue;
        console.log(`Mengirim pesan pushkontak ke: ${mem}`); 
        await mane.sendMessage(mem, { text: teks }, { quoted: pushkontakFakeReply });
        sentCount++;
        const randomDelay = Math.floor(Math.random() * (global.maxDelayPushkontak - global.minDelayPushkontak + 1)) + global.minDelayPushkontak;
        await sleep(randomDelay);
    }

    await m.reply(`*✅ Push Kontak Selesai*\nTotal pesan berhasil terkirim: ${sentCount} anggota.`);
}
break;
case 'winkvideo': {
    mane.videohd = mane.videohd || {};
    if (m.sender in mane.videohd) return m.reply("Sabar, lagi proses ya, jangan dispam.");

    if (!text) return m.reply(`Contoh: ${prefix + command} 1080 60fps`);

    const resolutions = {
        "480": "480", "720": "720", "1080": "1080",
        "2k": "1440", "4k": "2160", "8k": "4320"
    };

    let [res, fpsText] = text?.trim().toLowerCase().split(" ");
    let fps = 60;
    if (fpsText && fpsText.endsWith("fps")) {
        fps = parseInt(fpsText.replace("fps", ""));
        if (isNaN(fps) || fps < 30 || fps > 240) {
            return m.reply("❗ FPS harus antara 30 - 240 (contoh: 60fps)");
        }
    }

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';
    if (!/^video/.test(mime)) return m.reply("Perintah ini hanya untuk video. Silakan reply video yang ingin diubah.");
    
    if (!resolutions[res]) return m.reply(`Resolusi tidak valid.\n\nPilihan: ${Object.keys(resolutions).join(", ")}\nContoh: ${prefix + command} 1080`);

    mane.videohd[m.sender] = true;
    let inputPath;
    let outputPath;

    try {
        await m.reply(`⏳ Mengubah video ke ${res.toUpperCase()} ${fps}FPS...`);
        
        const tmpDir = './tmp';
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }

        const id = m.sender.split("@")[0];
        inputPath = `./tmp/input_${id}.mp4`;
        outputPath = `./tmp/hdvideo_${id}.mp4`;
        
        const buffer = await mane.downloadMediaMessage(q);
        fs.writeFileSync(inputPath, buffer);

        if (!fs.existsSync(inputPath)) {
            throw new Error("Gagal menyimpan file video sementara. Cek izin folder atau coba lagi.");
        }

        const targetHeight = resolutions[res];
        const form = new FormData();
        form.append("video", fs.createReadStream(inputPath));
        form.append("resolution", targetHeight);
        form.append("fps", fps);

        const response = await axios.post("http://193.149.164.168:4167/hdvideo", form, {
            headers: form.getHeaders(), maxBodyLength: Infinity,
            maxContentLength: Infinity, responseType: "stream"
        });

        const writer = fs.createWriteStream(outputPath);
        response.data.pipe(writer);

        writer.on("finish", async () => {
            try {
                const videoBuffer = fs.readFileSync(outputPath);
                await mane.sendMessage(m.chat, {
                    video: videoBuffer, mimetype: 'video/mp4',
                    fileName: `video_${res}_${fps}fps.mp4`,
                    caption: `✅ Video berhasil diubah ke ${res.toUpperCase()} ${fps}FPS`
                }, { quoted: m });
            } catch (sendError) {
                m.reply("Gagal mengirim video yang telah diproses.");
            } finally {
                delete mane.videohd[m.sender];
                if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
                if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
            }
        });
        
        writer.on("error", (err) => {
            throw new Error("Gagal menulis file video yang telah diproses.");
        });

    } catch (e) {
        m.reply("Terjadi kesalahan: " + e.message);
        delete mane.videohd[m.sender];
        if (inputPath && fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
        if (outputPath && fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    }
}
break;
        case 'botakin': {
  try {
    const quoted = m.quoted || m
    const mime = (quoted.msg || quoted).mimetype || ''
    if (!mime || !/image/.test(mime)) {
      return m.reply('❌ Kirim atau reply gambar dengan caption *.tobotak*')
    }

    m.reply('🧑‍🦲 Sedang memproses...')

    const fs = require('fs')
    const axios = require('axios')
    const FormData = require('form-data')

    const mediaPath = await mane.downloadAndSaveMediaMessage(quoted)

    const form = new FormData()
    form.append('file', fs.createReadStream(mediaPath))
    const cloudRes = await axios.post('https://cloudgood.xyz/upload.php', form, {
      headers: form.getHeaders(),
      maxContentLength: Infinity,
      maxBodyLength: Infinity
    })

    const imageUrl = cloudRes.data?.url
    fs.unlinkSync(mediaPath)
    if (!imageUrl) return m.reply('❌ Gagal upload gambar ke CloudGood.')

    await mane.sendMessage(m.chat, {
      image: { url: `https://api-faa-skuarta.vercel.app/faa/tobotak?url=${encodeURIComponent(imageUrl)}` },
      caption: '✅ Nih jadi botak 🧑‍🦲'
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply(`❌ Terjadi kesalahan:\n${err.message}`)
  }
}
break
    case 'jadwalsholat':
    case 'jadwal-sholat': {
        if (!text) return m.reply('Mau lihat jadwal sholat di kota mana?\nContoh: .jadwalsholat surabaya');
        await m.reply('⏳ Mencari jadwal sholat...');
        try {
            const citySearch = await fetchJson(`https://api.myquran.com/v2/sholat/kota/cari/${text}`);
            if (!citySearch.status || citySearch.data.length === 0) {
                return m.reply(`Kota "${text}" tidak ditemukan. Coba gunakan nama kota yang lebih spesifik.`);
            }
            const cityId = citySearch.data[0].id;
            const today = new Date().toISOString().slice(0, 10); // Format YYYY-MM-DD
            const schedule = await fetchJson(`https://api.myquran.com/v2/sholat/jadwal/${cityId}/${today}`);

            if (!schedule.status) {
                return m.reply('Gagal mengambil jadwal sholat untuk kota tersebut.');
            }
            const jadwal = schedule.data.jadwal;
            const responseText = `
*JADWAL SHOLAT UNTUK HARI INI*
*Kota:* ${schedule.data.lokasi}
*Tanggal:* ${jadwal.tanggal}

- Imsak: ${jadwal.imsak}
- Subuh: ${jadwal.subuh}
- Terbit: ${jadwal.terbit}
- Dhuha: ${jadwal.dhuha}
- Dzuhur: ${jadwal.dzuhur}
- Ashar: ${jadwal.ashar}
- Maghrib: ${jadwal.maghrib}
- Isya: ${jadwal.isya}
            `.trim();
            m.reply(responseText);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan saat mengambil data jadwal sholat.');
        }
    }
    break;

    case 'asmaulhusna': {
        try {
            await m.reply('⏳ Memuat Asmaul Husna...');
            let data = await fetchJson('https://islamic-api-zhirrr.vercel.app/api/asmaulhusna');
            let asmaul = data.data;

            let responseText = '*ASMAUL HUSNA*\n\n' + asmaul.map((item) => {
              return `*${item.index}. ${item.latin} (${item.arabic})*\nArtinya: ${item.translation_id}\n`;
            }).join('\n');

            m.reply(responseText);
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengambil data Asmaul Husna.');
        }
    }
    break;

    case 'niatsholat':
    case 'niat-sholat': {
        try {
            let listNiat = await fetchJson('https://islamic-api-zhirrr.vercel.app/api/niatshalat');

            if (!text) {
              let daftarNiat = '*DAFTAR NIAT SHOLAT*\n\n' + listNiat.map((item) => `- ${item.name}`).join('\n');
              daftarNiat += '\n\nKetik `.niatsholat [nama sholat]` untuk melihat niat, contoh: `.niatsholat subuh`';
              m.reply(daftarNiat);
            } else {
              let hasil = listNiat.find((item) => item.name.toLowerCase().includes(text.toLowerCase()));
              if (hasil) {
                let responseText = `*NIAT SHOLAT ${hasil.name.toUpperCase()}*\n\n` +
                  `*Arab:* ${hasil.arabic}\n\n` +
                  `*Latin:* ${hasil.latin}\n\n` +
                  `*Terjemahan:* ${hasil.terjemahan}`;
                m.reply(responseText);
              } else {
                m.reply('Niat sholat yang kamu cari tidak ditemukan. Cek kembali nama sholatnya.');
              }
            }
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengambil data niat sholat.');
        }
    }
    break;

    

    case 'doa':
    case 'berdoa': {
        try {
            let listDoa = await fetchJson('https://doa-doa-api-ahmadramadhan.fly.dev/api');
            if (!text) {
              let daftarDoa = '*DAFTAR DOA*\n\n' + listDoa.map((item) => `- ${item.doa}`).join('\n');
              daftarDoa += '\n\nKetik `.doa [nama doa]` untuk melihat doa, contoh: `.doa doa sebelum tidur`';
              m.reply(daftarDoa);
            } else {
              let hasil = listDoa.find((item) => item.doa.toLowerCase().includes(text.toLowerCase()));
              if (hasil) {
                let responseText = `*DOA: ${hasil.doa.toUpperCase()}*\n\n` +
                  `*Ayat:* ${hasil.ayat}\n\n` +
                  `*Latin:* ${hasil.latin}\n\n` +
                  `*Artinya:* ${hasil.artinya}`;
                m.reply(responseText);
              } else {
                m.reply('Doa yang kamu cari tidak ditemukan. Cek kembali nama doanya.');
              }
            }
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengambil data doa.');
        }
    }
    break;


    case "hitamkan": {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    const defaultPrompt = `ubah warna kulit karakter menjadi warna hitam`;

    if (!mime) return m.reply(`Kirim/reply gambar dengan caption *${prefix + command}*`);
    if (!/image\/(jpe?g|png)/.test(mime)) return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png`);

    const promptText = text || defaultPrompt;
    await m.reply("⏳ Tunggu Sebentar, sedang memproses gambar...");

    try {
        const tmpDir = './tmp';
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }

        const imgData = await q.download();
        const genAI = new GoogleGenerativeAI("AIzaSyDE7R-5gnjgeqYGSMGiZVjA5VkSrQvile8");
        const base64Image = imgData.toString("base64");

        const contents = [
            { text: promptText },
            {
                inlineData: {
                    mimeType: mime,
                    data: base64Image
                }
            }
        ];

        const model = genAI.getGenerativeModel({
            model: "gemini-2.0-flash-exp-image-generation",
            generationConfig: {
                responseModalities: ["Text", "Image"]
            },
        });

        const response = await model.generateContent(contents);
        let resultImage;
        for (const part of response.response.candidates[0].content.parts) {
            if (part.inlineData) {
                const imageData = part.inlineData.data;
                resultImage = Buffer.from(imageData, "base64");
            }
        }

        if (resultImage) {
            const tempPath = path.join(__dirname, 'tmp', `gemini_${Date.now()}.png`);
            fs.writeFileSync(tempPath, resultImage);

            await mane.sendMessage(m.chat, {
                image: { url: tempPath },
                caption: `*Maaf jika tidak sesuai*`
            }, { quoted: m });

            setTimeout(() => {
                try {
                    fs.unlinkSync(tempPath);
                } catch {}
            }, 30000);
        } else {
            await m.reply("Gagal mengedit gambar. Tidak ada gambar yang dihasilkan.");
        }
    } catch (error) {
        console.error(error);
        await m.reply(`Error: ${error.message}`);
    }
}
break;

   case 'sholat': {
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");
    if (!m.isAdmin && !isOwner) return m.reply('Hanya admin dan owner yang bisa menggunakan perintah ini.');

    const subcommand = args[0]?.toLowerCase();
    
    if (!subcommand) {
        const status = global.prayerReminderGroups.includes(m.chat) ? 'AKTIF' : 'NON-AKTIF';
        return m.reply(`Status pengingat sholat di grup ini: *${status}*\n\nGunakan:\n- ${prefix}sholat on (untuk mengaktifkan)\n- ${prefix}sholat off (untuk menonaktifkan)`);
    }

    if (subcommand === 'on') {
        if (global.prayerReminderGroups.includes(m.chat)) {
            return m.reply("Pengingat sholat sudah aktif di grup ini.");
        }
        
        global.prayerReminderGroups.push(m.chat);
        savePrayerReminderGroups(global.prayerReminderGroups);
        await m.reply("✅ Pengingat sholat telah diaktifkan di grup ini. Bot akan mengirim pengingat ketika waktu sholat tiba.");
        
    } else if (subcommand === 'off') {
        const index = global.prayerReminderGroups.indexOf(m.chat);
        if (index === -1) {
            return m.reply("Pengingat sholat belum aktif di grup ini.");
        }
        
        global.prayerReminderGroups.splice(index, 1);
        savePrayerReminderGroups(global.prayerReminderGroups);
        await m.reply("✅ Pengingat sholat telah dinonaktifkan di grup ini.");
        
    } else {
        m.reply(`Subperintah tidak dikenali. Gunakan:\n- ${prefix}sholat on\n- ${prefix}sholat off`);
    }
}
break;
case 'autoread': {
    if (!isOwner) return m.reply(mess.owner);
    const action = args[0]?.toLowerCase();

    if (action === 'on') {
        if (global.autoread) return m.reply("Fitur autoread sudah aktif.");
        global.autoread = true;
        m.reply("✅ Fitur autoread berhasil diaktifkan.");
    } else if (action === 'off') {
        if (!global.autoread) return m.reply("Fitur autoread sudah nonaktif.");
        global.autoread = false;
        m.reply("✅ Fitur autoread berhasil dinonaktifkan.");
    } else {
        const status = global.autoread ? 'Aktif' : 'Nonaktif';
        m.reply(`Status Autoread saat ini: *${status}*\n\nGunakan:\n- ${prefix}autoread on\n- ${prefix}autoread off`);
    }
}
break;

case 'iqc': {
    
    let inputText = args.length > 0 
        ? args.join(" ")
        : (m.quoted && m.quoted.text ? m.quoted.text : "");

    if (!inputText) {
        return m.reply(`Contoh Penggunaan:\n.iqc teks anda di sini\natau reply pesan dengan .iqc`);
    }

    function formatText(text) {
        const applyStyle = (text, map) => {
            let result = '';
            for (const char of text) {
                result += map[char] || char;
            }
            return result;
        };

        const styles = {
            bold: {
                'a':'𝗮','b':'𝗯','c':'𝗰','d':'𝗱','e':'𝗲','f':'𝗳','g':'𝗴','h':'𝗵','i':'𝗶','j':'𝗷','k':'𝗸','l':'𝗹','m':'𝗺','n':'𝗻','o':'𝗼','p':'𝗽','q':'𝗾','r':'𝗿','s':'𝘀','t':'𝘁','u':'𝘂','v':'𝘃','w':'𝘄','x':'𝘅','y':'𝘆','z':'𝘇',
                'A':'𝗔','B':'𝗕','C':'𝗖','D':'𝗗','E':'𝗘','F':'𝗙','G':'𝗚','H':'𝗛','I':'𝗜','J':'𝗝','K':'𝗞','L':'𝗟','M':'𝗠','N':'𝗡','O':'𝗢','P':'𝗣','Q':'𝗤','R':'𝗥','S':'𝗦','T':'𝗧','U':'𝗨','V':'𝗩','W':'𝗪','X':'𝗫','Y':'𝗬','Z':'𝗭'
            },
            italic: {
                'a':'𝘢','b':'𝘣','c':'𝘤','d':'𝘥','e':'𝘦','f':'𝘧','g':'𝘨','h':'𝘩','i':'𝘪','j':'𝘫','k':'𝘬','l':'𝘭','m':'𝘮','n':'𝘯','o':'𝘰','p':'𝘱','q':'𝘲','r':'𝘳','s':'𝘴','t':'𝘵','u':'𝘶','v':'𝘷','w':'𝘸','x':'𝘹','y':'𝘺','z':'𝘻',
                'A':'𝘈','B':'𝘉','C':'𝘊','D':'𝘋','E':'𝘌','F':'𝘍','G':'𝘎','H':'𝘏','I':'𝘐','J':'𝘑','K':'𝘒','L':'𝘓','M':'𝘔','N':'𝘕','O':'𝘖','P':'𝘗','Q':'𝘘','R':'𝘙','S':'𝘚','T':'𝘛','U':'𝘜','V':'𝘝','W':'𝘞','X':'𝘟','Y':'𝘠','Z':'𝘡'
            }
        };

        return text
            .replace(/\*(.*?)\*/g, (_, c) => applyStyle(c, styles.bold))
            .replace(/_(.*?)_/g, (_, c) => applyStyle(c, styles.italic))
            .replace(/~(.*?)~/g, (_, c) => c.split('').map(ch => ch + '\u0336').join(''));
    }

    await m.reply('⏳ Sedang membuat gambar...');

    try {
        const formattedText = formatText(inputText);

        const maxLength = 1000;
        let processedText = formattedText.length > maxLength
            ? formattedText.substring(0, maxLength) + '...'
            : formattedText;

        const time = new Intl.DateTimeFormat('id-ID', {
            timeZone: 'Asia/Jakarta',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false
        }).format(new Date());
        const batteryPercentage = Math.floor(Math.random() * 100) + 1;

        const imageUrl = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&batteryPercentage=${batteryPercentage}&carrierName=INDOSAT&messageText=${encodeURIComponent(processedText.trim())}&emojiStyle=apple`;

        await mane.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: "✅ Berhasil, semoga suka yaah"
        }, { quoted: m });

    } catch (error) {
        console.error("Error iqc:", error.message);
        return m.reply("⚠️ Terjadi kesalahan saat membuat gambar, coba ulangi.");
    }
}
break;

case 'alkitab': {
    if (!text) return m.reply('Format: .alkitab <Kitab> <Pasal> [Ayat]\nContoh: .alkitab Yohanes 3 16 atau .alkitab Yohanes 3')

    const parts = text.trim().split(/\s+/)
    if (parts.length < 2) return m.reply('Format salah. Contoh: .alkitab Yohanes 3 16')

    const kitab = parts[0]
    const pasal = parts[1]
    const ayat = parts[2] || null

    try {
        let url = `https://api.ayt.co/v1/bible.php?book=${encodeURIComponent(kitab)}&chapter=${encodeURIComponent(pasal)}${ayat ? `&verse=${ayat}` : ''}&source=elaina-bot`
        let res = await fetchJson(url)

        let bookKey = Object.keys(res)[0]
        if (!bookKey) return m.reply('*sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ*\nKitab tidak ditemukan.')

        let info = res[bookKey].info
        let data = res[bookKey].data[pasal]
        if (!data) return m.reply('*sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ*\nPasal tidak ditemukan.')

        let teksAyat = ''
        if (ayat) {
            let found = Object.values(data).find(v => v.verse == ayat)
            if (!found) return m.reply('*sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ*\nAyat tidak ditemukan.')
            teksAyat = `(${found.verse}) ${found.text}`
        } else {
            teksAyat = Object.values(data)
                .map(v => `(${v.verse}) ${v.text}`)
                .join('\n')
        }

        let output = `📖 *ALKITAB* — ${info.book_name} ${pasal}${ayat ? ':' + ayat : ''}\n\n${teksAyat}`
        m.reply(output)
    } catch (err) {
        console.error(err)
        m.reply('*sʏsᴛᴇᴍ ɴᴏᴛɪᴄᴇ*\nTerjadi kesalahan saat mengambil data Alkitab.')
    }
}
break;

case 'doakristen': {
    const doaList = `
🙏 *Doa Kristen Sehari-hari* 🙏

• Doa Pagi
"Tuhan, terima kasih atas hari yang baru ini..."

• Doa Malam
"Tuhan Yesus, terima kasih atas penyertaan-Mu..."

• Doa Sebelum Makan
"Tuhan, berkati makanan ini..."
`;
    m.reply(doaList);
}
break;


case 'renungan': {
    const daftarRenungan = [
        {
            judul: "Mengandalkan Kekuatan Tuhan",
            ayat: "Filipi 4:13",
            teks: "Segala perkara dapat kutanggung di dalam Dia yang memberi kekuatan kepadaku.",
            isi: "Dalam setiap tantangan dan kesulitan, janganlah bersandar pada kekuatan diri sendiri. Ingatlah bahwa sumber kekuatan sejati datang dari Tuhan. Saat kita merasa lemah, Dia akan menjadi kekuatan kita untuk menghadapi apa pun."
        },
        {
            judul: "Jangan Kuatir",
            ayat: "Matius 6:34",
            teks: "Sebab itu janganlah kamu kuatir akan hari besok, karena hari besok mempunyai kesusahannya sendiri. Kesusahan sehari cukuplah untuk sehari.",
            isi: "Kekuatiran akan masa depan seringkali merampas sukacita kita hari ini. Tuhan mengajarkan kita untuk fokus pada hari ini dan percaya bahwa Dia telah menyediakan segala yang kita perlukan. Serahkanlah kekuatiranmu kepada-Nya."
        },
        {
            judul: "Kasih yang Utama",
            ayat: "1 Korintus 13:4-5",
            teks: "Kasih itu sabar; kasih itu murah hati; ia tidak cemburu. Ia tidak memegahkan diri dan tidak sombong. Ia tidak melakukan yang tidak sopan dan tidak mencari keuntungan diri sendiri.",
            isi: "Kasih adalah dasar dari iman kita. Renungkanlah setiap hari apakah kita sudah menunjukkan kasih yang sabar dan tulus kepada sesama, tanpa mengharapkan balasan. Jadilah saluran kasih Tuhan bagi dunia."
        },
        {
            judul: "Menjadi Terang",
            ayat: "Matius 5:16",
            teks: "Demikianlah hendaknya terangmu bercahaya di depan orang, supaya mereka melihat perbuatanmu yang baik dan memuliakan Bapamu yang di sorga.",
            isi: "Setiap perbuatan baik yang kita lakukan adalah cerminan dari terang Tuhan dalam hidup kita. Jangan sembunyikan terang itu. Biarlah melalui tindakan dan perkataan kita, orang lain dapat melihat kemuliaan Tuhan."
        },
        {
            judul: "Pengharapan dalam Iman",
            ayat: "Ibrani 11:1",
            teks: "Iman adalah dasar dari segala sesuatu yang kita harapkan dan bukti dari segala sesuatu yang tidak kita lihat.",
            isi: "Iman bukanlah sekadar percaya, tetapi sebuah keyakinan yang teguh pada janji-janji Tuhan, bahkan ketika kita belum melihatnya terwujud. Teruslah berpegang pada iman, karena itu adalah jangkar bagi jiwa kita."
        }
    ];

    const renungan = daftarRenungan[Math.floor(Math.random() * daftarRenungan.length)];

    const replyText = `*Renungan Harian ✨*\n\n` +
                      `*Judul:* ${renungan.judul}\n` +
                      `*Ayat:* _${renungan.teks}_ (*${renungan.ayat}*)\n\n` +
                      `${renungan.isi}`;
                      
    await m.reply(replyText);
}
break;

case 'jadwalibadah': {
    const jadwal = `
⛪ *Jadwal Ibadah Mingguan* ⛪

• Minggu, 09:00 WIB - Ibadah Raya
• Rabu, 19:00 WIB - Ibadah Doa
• Jumat, 19:00 WIB - Persekutuan Pemuda
`;
    m.reply(jadwal);
}
break;
case 'enc': {
    if (!isOwner) return m.reply("Perintah ini hanya untuk Owner.");

    if (!m.quoted) return m.reply("❌ Format salah.\nHarap balas (reply) file yang ingin di-enkripsi dengan perintah:\n*.enc Nama Kustom*");

    const customName = args.join(" ").trim();
    if (!customName) return m.reply("❌ Nama kustom tidak boleh kosong.\nContoh:\n.enc Script Elaina");

    const quotedMsg = m.quoted;
    const mime = (quotedMsg.msg || quotedMsg).mimetype || "";
    const originalFileName = (quotedMsg.msg || quotedMsg).fileName || `file.js`;

    if (!/text|javascript|json/.test(mime) && quotedMsg.mtype !== 'documentMessage') {
        return m.reply(`❌ File tidak didukung. Harap balas file kode seperti .js, .json, atau file teks.`);
    }

    await m.reply(`⏳ Memproses enkripsi untuk file '${originalFileName}'...`);

    try {
        const fileBuffer = await quotedMsg.download();
        if (fileBuffer.length === 0) return m.reply("❌ File yang Anda kirim kosong.");

        const fileContent = fileBuffer.toString('utf8');
        
        const randomHex = crypto.randomBytes(4).toString('hex');
        const dataVar = `_maneData_${randomHex}`;
        const keyVar = `_maneKey_${randomHex}`;

        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        
        let shuffledChars = (chars + customName).split('').sort(() => 0.5 - Math.random()).join('');
        shuffledChars = [...new Set(shuffledChars.split(''))].join('');

        const charMap = {};
        for (let i = 0; i < chars.length; i++) {
            charMap[chars[i]] = shuffledChars[i];
        }

        const base64Content = Buffer.from(fileContent).toString('base64');
        let substitutedContent = '';
        for (const char of base64Content) {
            substitutedContent += charMap[char] || char;
        }
        
        const finalCode = `
const ${keyVar} = '${shuffledChars}';
const ${dataVar} = '${substitutedContent}';
const originalChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
let decodedB64 = '';
for (const char of ${dataVar}) {
    const originalCharIndex = ${keyVar}.indexOf(char);
    if (originalCharIndex !== -1 && originalCharIndex < originalChars.length) {
        decodedB64 += originalChars[originalCharIndex];
    } else {
        decodedB64 += char;
    }
}
eval(Buffer.from(decodedB64, 'base64').toString('utf8'));
`;

        const newFileName = `enc-${originalFileName}`;
        
        const tmpDir = './tmp';
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }
        const tempFilePath = path.join(tmpDir, newFileName);

        fs.writeFileSync(tempFilePath, finalCode);

        await mane.sendMessage(m.chat, {
            document: fs.readFileSync(tempFilePath),
            mimetype: 'application/javascript',
            fileName: newFileName,
            caption: `✅ Berhasil mengenkripsi file '${originalFileName}'.`
        }, { quoted: m });
        
        fs.unlinkSync(tempFilePath);

    } catch (error) {
        console.error("Encryption Error:", error);
        m.reply(`❌ Terjadi kesalahan saat mengenkripsi file: ${error.message}`);
    }
}
break;
        case 'enc2': {
    if (!isOwner) return m.reply("Perintah ini hanya untuk Owner.");

    if (!m.quoted) return m.reply("❌ Format salah.\nHarap balas (reply) file yang ingin di-enkripsi dengan perintah:\n*.enc Nama Kustom*");

    const customName = args.join(" ").trim();
    if (!customName) return m.reply("❌ Nama kustom tidak boleh kosong.\nContoh:\n.enc Script Elaina");

    const quotedMsg = m.quoted;
    const mime = (quotedMsg.msg || quotedMsg).mimetype || "";
    const originalFileName = (quotedMsg.msg || quotedMsg).fileName || `file.js`;

    if (!/text|javascript|json/.test(mime) && quotedMsg.mtype !== 'documentMessage') {
        return m.reply(`❌ File tidak didukung. Harap balas file kode seperti .js, .json, atau file teks.`);
    }

    await m.reply(`⏳ Memproses enkripsi untuk file '${originalFileName}'...`);

    try {
        const fileBuffer = await quotedMsg.download();
        if (fileBuffer.length === 0) return m.reply("❌ File yang Anda kirim kosong.");

        const fileContent = fileBuffer.toString('utf8');
        
        const randomHex = crypto.randomBytes(4).toString('hex');
        const dataVar = `_maneData_${randomHex}`;
        const keyVar = `_maneKey_${randomHex}`;

        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        
        let shuffledChars = (chars + customName).split('').sort(() => 0.5 - Math.random()).join('');
        shuffledChars = [...new Set(shuffledChars.split(''))].join('');

        const charMap = {};
        for (let i = 0; i < chars.length; i++) {
            charMap[chars[i]] = shuffledChars[i];
        }

        const base64Content = Buffer.from(fileContent).toString('base64');
        let substitutedContent = '';
        for (const char of base64Content) {
            substitutedContent += charMap[char] || char;
        }
        
        const finalCode = `
/* Obfuscated by Elaina BOT */
const ${keyVar} = '${shuffledChars}';
const ${dataVar} = '${substitutedContent}';
const originalChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
let decodedB64 = '';
for (const char of ${dataVar}) {
    const originalCharIndex = ${keyVar}.indexOf(char);
    if (originalCharIndex !== -1 && originalCharIndex < originalChars.length) {
        decodedB64 += originalChars[originalCharIndex];
    } else {
        decodedB64 += char;
    }
}
eval(Buffer.from(decodedB64, 'base64').toString('utf8'));
`;

        const newFileName = `enc-${originalFileName}`;
        
        const tmpDir = './tmp';
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }
        const tempFilePath = path.join(tmpDir, newFileName);

        fs.writeFileSync(tempFilePath, finalCode);

        await mane.sendMessage(m.chat, {
            document: fs.readFileSync(tempFilePath),
            mimetype: 'application/javascript',
            fileName: newFileName,
            caption: `✅ Berhasil mengenkripsi file '${originalFileName}'.`
        }, { quoted: m });
        
        fs.unlinkSync(tempFilePath);

    } catch (error) {
        console.error("Encryption Error:", error);
        m.reply(`❌ Terjadi kesalahan saat mengenkripsi file: ${error.message}`);
    }
}
break;
default:       
if (budy.startsWith('$')) {
    if (!isOwner) return;
    exec(budy.slice(1), (err, stdout, stderr) => {
        if (err) return m.reply(util.format(err));
        if (stderr) return m.reply(util.format(stderr));
        if (stdout) return m.reply(util.format(stdout));
    });
}

if (budy.startsWith(">") || budy.startsWith("=>")) {
    if (!isOwner) return;
    const command = budy.startsWith("=>") ? budy.slice(2) : budy.slice(1);
    try {
        const evaling = await eval(`;(async () => { ${command} })();`);
        m.reply(util.format(evaling));
    } catch (e) {
        m.reply(util.format(e));
    }
}
break;

}
} catch (e) {
    console.log(e);
    mane.sendMessage(`${global.owner}@s.whatsapp.net`, {text: `Terjadi error pada:\n${m.text}\n\n${util.format(e)}`});
}
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`));
    delete require.cache[file];
    require(file);
});