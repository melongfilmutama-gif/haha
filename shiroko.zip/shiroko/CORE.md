# **ZassOneMods – ID**

**© 2025 ZassOneMods**  
_All rights reserved._

### ▶︎ Ketentuan
- Dilarang memperjualbelikan atau mengklaim ulang sebagian maupun seluruh kode ini tanpa izin tertulis dari Developer.
- Script ini dapat digunakan, dimodifikasi, dan dibagikan ulang **hanya** untuk tujuan pribadi atau pengembangan.
- Atribusi ke **ZassOneMods** wajib dicantumkan di setiap salinan atau turunan kode.

### ⚠︎ Penafian
Penggunaan script ini sepenuhnya menjadi tanggung jawab pengguna.  
Developer dan kontributor tidak bertanggung jawab atas kerusakan, pelanggaran hukum, atau kerugian yang timbul akibat penggunaan script ini.

### ⚙︎ Sumber Resmi & Pembaruan
[https://www.neolabsofficial.my.id](https://www.neolabsofficial.my.id)  

**Dikembangkan oleh:** `NSLabs Team`

____________________

# **ZassOneMods – EN**

**© 2025 ZassOneMods**  
_All rights reserved._

### ▶︎ Provision
- It is prohibited to sell or reclaim part or all of this code without written permission from the Developer.
- This script can be used, modified, and re-shared **only** for personal or development purposes.
- Attribution to **ZassOneMods** is required with any copy or derivative of the code.

### ⚠︎ Disclaimer
Use of this script is entirely the responsibility of the user.  
Developers and contributors are not responsible for any damage, violation of law, or loss arising from the use of this script.

### ⚙︎ Official Sources & Updates
[https://www.neolabsofficial.my.id](https://www.neolabsofficial.my.id)  

**Made by:** `NSLabs Team`