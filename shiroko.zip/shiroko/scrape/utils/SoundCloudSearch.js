const axios = require("axios");
const cheerio = require("cheerio");

async function SoundSearch(search) {
  return new Promise(async (resolve, reject) => {
    try {
      const { data, status } = await axios.get(
        `https://soundcloud.com/search?q=${search}`,
      );
      const $ = cheerio.load(data);
      const ajg = [];
      $("#app > noscript").each((u, i) => {
        ajg.push($(i).html());
      });
      const _$ = cheerio.load(ajg[1]);
      const hasil = [];
      _$("ul > li > h2 > a").each((i, u) => {
        if ($(u).attr("href").split("/").length === 3) {
          const linkk = $(u).attr("href");
          const judul = $(u).text();
          const link = linkk ? linkk : "Tidak ditemukan";
          const jdi = `https://soundcloud.com${link}`;
          const jadu = judul ? judul : "Tidak ada judul";
          hasil.push({
            link: jdi,
            judul: jadu,
          });
        }
      });
      if (hasil.every((x) => x === undefined))
        return { developer: "@Zeltoria", mess: "no result found" };
      resolve(hasil);
    } catch (err) {
      console.error(err);
    }
  });
}

module.exports = { SoundSearch };
