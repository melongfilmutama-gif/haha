let db_saldo = {}; // Simulasi database saldo pengguna

let saldoHandler = async (m, { conn, command }) => {
  let userId = m.sender;

  if (!db_saldo[userId]) {
    db_saldo[userId] = 0; // Jika tidak ada, set saldo awal menjadi 0
  }

  let currentSaldo = db_saldo[userId];

  await conn.sendMessage(
    m.chat,
    { text: `💰 Saldo Anda saat ini adalah: Rp ${currentSaldo}\n\nTerima kasih telah menggunakan layanan kami!` },
    m
  );
};

saldoHandler.help = saldoHandler.command = ["saldo"];
saldoHandler.tags = ["store"];

module.exports = saldoHandler;

// Fungsi untuk menambahkan saldo, digunakan di handler lain
function addSaldo(userId, amount, db_saldo) {
  if (!db_saldo[userId]) {
    db_saldo[userId] = 0;
  }
  db_saldo[userId] += amount;
}