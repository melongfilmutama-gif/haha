/*═══════════════════════════════════════════════════════
 *  ⌬  YT NeoShiroko Labs
 *═══════════════════════════════════════════════════════
 *  🌐  Website     : https://www.neolabsofficial.my.id
 *  ⌨︎  Developer   : https://zass.cloud
 *  ▶︎  YouTube     : https://www.youtube.com/@zassci_desu
 *  ⚙︎  Panel Murah : pteroku-desu.zass.cloud
 *
 *  ⚠︎  Mohon untuk tidak menghapus watermark ini
 *═══════════════════ © 2025 Zass Desuta ─════════════════════
 */
let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Masukan URL!\n\ncontoh:\n${usedPrefix + command} https://youtu.be/JZNfVd0yd2w`;      

    m.reply(wait);        

    try {
        let url, format, type
        if (command === 'ytmp3') {
            url = `https://api.nekoo.qzz.io/downloader/youtube?url=${encodeURIComponent(text)}&format=320&type=audio`
            format = 'audio'
            type = 'audio/mpeg'
        } else if (command === 'ytmp4') {
            url = `https://api.nekoo.qzz.io/downloader/youtube?url=${encodeURIComponent(text)}&format=720&type=video`
            format = 'video'
            type = 'video/mp4'
        }

        const response = await fetch(url)
        const res = await response.json()

        if (!res.status || !res.result) throw `Gagal mengambil data ${command.toUpperCase()}!`

        const { title, format: resFormat, cover, downloadUrl } = res.result

        let caption = `*YouTube ${command.toUpperCase()} Downloader*\n\n`
        caption += `◦ *Title:* ${title}\n`
        caption += `◦ *Format:* ${resFormat}${command === 'ytmp3' ? ' kbps' : 'p'}\n`

        if (command === 'ytmp3') {
            await conn.sendMessage(m.chat, {   
                audio: { url: downloadUrl },   
                mimetype: type,  
                ptt: false,
                contextInfo: {
                    externalAdReply: {
                        title: title,
                        body: `Format: ${resFormat} kbps`,
                        thumbnailUrl: cover,
                        sourceUrl: text,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, {   
                video: { url: downloadUrl },   
                mimetype: type,
                caption,
                contextInfo: {
                    externalAdReply: {
                        title: title,
                        body: `Format: ${resFormat}p`,
                        thumbnailUrl: cover,
                        sourceUrl: text,
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m })
        }

    } catch (err) {
        console.error(err)
        m.reply(eror)
    }
}

handler.help = ['ytmp3 <url>', 'ytmp4 <url>']
handler.command = /^(ytmp3|ytmp4)$/i
handler.tags = ['downloader']
handler.limit = true

module.exports = handler