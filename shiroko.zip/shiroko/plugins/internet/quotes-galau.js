/*═══════════════════════════════════════════════════════
 *  ⌬  YT NeoShiroko Labs
 *═══════════════════════════════════════════════════════
 *  🌐  Website     : https://www.neolabsofficial.my.id
 *  ⌨︎  Developer   : https://zass.cloud
 *  ▶︎  YouTube     : https://www.youtube.com/@zassci_desu
 *  ⚙︎  Panel Murah : pteroku-desu.zass.cloud
 *
 *  ⚠︎  Mohon untuk tidak menghapus watermark ini
 *═══════════════════ © 2025 Zass Desuta ─════════════════════
 */

let handler = async (m, { conn }) => {
  conn.sendButton(m.chat, [["Next", ".galau"]], m, {
    body: pickRandom(global.galau),
  });
};
handler.help = ["galau"].map((a) => a + " *[random quotes]*");
handler.tags = ["quotes"];
handler.command = ["galau"];
module.exports = handler;

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}

global.galau = [
  "Gak salah kalo aku lebih berharap sama orang yang lebih pasti tanpa khianati janji-janji",
  "Rasanya baru kemarin kamu menawariku seblak. Lalu entah mengapa hari ini menanyakan kabar pun tidak.\n~vinaa",
  "What's the point of us being close yesterday?\n~Vinaa",
  "Kamu tidak bisa memaksa seseorang untuk menomor satukan dirimu, sebab prioritas dengan kebutuhan itu jelas beda.\n*BY PUTRI*",
  "Hubungan kita hanya sampai dilisan, tidak sampai dipertemukan.\n*BY PUTRI*",
  "Dia sesuka hati, kamu setulus hati.\n*BY PUTRI*",
  "Mengakhiri bukan berarti tidak mau berjuang lagi...hanya saja aku tidak mau ada lgi,hati yg tersakiti.\n\nBy putri",
  "Maaf. Tidak ada waktu untuk meladeni gabutmu. Karena aku sibuk dengan kesibukan ku.\n*BY PUTRI*",
  "Pelangimu mungkin banyak warna. Tapi, tak ada warna yang membuat dia menaruh rasa.\n*BY PUTRI*",
  "Bahagia terus ya,sampai saat ini lu masih jadi tokoh favorit dikisah hidup gue,luv u.\n\n*BY PUTRI*",
  "Sorry,gue ga kuat buat semuanya ,mksi ya\n\n*BY PUTRI*",
  "Kamu memang sosok yg tak terduga Mudah membuat ku bahagia,mudah membuatku hancur saat itu juga.\n\n*BY PUTRI*",
  "Harusnya kalo udah ga sayang sama aku tu bilang aja gausa di tutup tutupin\n*BY INDI*",
  "Kalau aku memang tidak sayang sama kamu ngapain aku mikirin kamu. Tapi semuanya kamu yang ngganggap aku gak sayang sama kamu",
  "Jangan iri dan sedih jika kamu tidak memiliki kemampuan seperti yang orang miliki. Yakinlah orang lain juga tidak memiliki kemampuan sepertimu",
  "Hanya kamu yang bisa membuat langkahku terhenti, sambil berkata dalam hati mana bisa aku meninggalkanmu",
  "Tetap tersenyum walaluku masih dibuat menunggu dan rindu olehmu, tapi itu demi kamu",
  "Tak semudah itu melupakanmu",
  "Secuek-cueknya kamu ke aku, aku tetap sayang sama kamu karena kamu telah menerima aku apa adanya",
  "Aku sangat bahagia jika kamu bahagia didekatku, bukan didekatnya",
  "Jadilah diri sendiri, jangan mengikuti orang lain, tetapi tidak sanggup untuk menjalaninya",
  "Cobalah terdiam sejenak untuk memikirkan bagaimana caranya agar kita dapat menyelesaikan masalah ini bersama-sama",
  "Bisakah kita tidak bermusuhan setelah berpisah, aku mau kita seperti dulu sebelum kita jadian yang seru-seruan bareng, bercanda dan yang lainnya",
  "Aku ingin kamu bisa langgeng sama aku dan yang aku harapkan kamu bisa jadi jodohku",
  "Cinta tak bisa dijelaskan dengan kata-kata saja, karena cinta hanya mampu dirasakan oleh hati",
  "Masalah terbesar dalam diri seseorang adalah tak sanggup melawan rasa takutnya",
  "Selamat pagi buat orang yang aku sayang dan orang yang membenciku, semoga hari ini hari yang lebih baik daripada hari kemarin buat aku dan kamu",
  "Jangan menyerah dengan keadaanmu sekarang, optimis karena optimislah yang bikin kita kuat",
  "Kepada pria yang selalu ada di doaku aku mencintaimu dengan tulus apa adanya",
  "Tolong jangan pergi saat aku sudah sangat sayang padamu",
  "Coba kamu yang berada diposisiku, lalu kamu ditinggalin gitu aja sama orang yang lo sayang banget",
  "Aku takut kamu kenapa-napa, aku panik jika kamu sakit, itu karena aku cinta dan sayang padamu",
  "Sakit itu ketika cinta yang aku beri tidak kamu hargai",
  "Kamu tiba-tiba berubah tanpa sebab tapi jika memang ada sebabnya kamu berubah tolong katakan biar saya perbaiki kesalahan itu",
  "Karenamu aku jadi tau cinta yang sesungguhnya",
  "Senyum manismu sangatlah indah, jadi janganlah sampai kamu bersedih",
  "Berawal dari kenalan, bercanda bareng, ejek-ejekan kemudian berubah menjadi suka, nyaman dan akhirnya saling sayang dan mencintai",
  "Tersenyumlah pada orang yang telah menyakitimu agar sia tau arti kesabaran yang luar biasa",
  "Aku akan ingat kenangan pahit itu dan aku akan jadikan pelajaran untuk masa depan yang manis",
  "Kalau memang tak sanggup menepati janjimu itu setidaknya kamu ingat dan usahakan jagan membiarkan janjimu itu sampai kau lupa",
  "Hanya bisa diam dan berfikir Kenapa orang yang setia dan baik ditinggalin yang nakal dikejar-kejar giliran ditinggalin bilangnya laki-laki itu semuanya sama",
  "Walaupun hanya sesaat saja kau membahagiakanku tapi rasa bahagia yang dia tidak cepat dilupakan",
  "Aku tak menyangka kamu pergi dan melupakan ku begitu cepat",
  "Jomblo gak usah diam rumah mumpung malam minggu ya keluar jalan lah kan jomblo bebas bisa dekat sama siapapun pacar orang mantan sahabat bahkan sendiri atau bareng setan pun bisa",
  "Kamu adalah teman yang selalu di sampingku dalam keadaan senang maupun susah Terimakasih kamu selalu ada di sampingku",
  "Aku tak tahu sebenarnya di dalam hatimu itu ada aku atau dia",
  "Tak mudah melupakanmu karena aku sangat mencintaimu meskipun engkau telah menyakiti aku berkali-kali",
  "Hidup ini hanya sebentar jadi lepaskan saja mereka yang menyakitimu Sayangi Mereka yang peduli padamu dan perjuangan mereka yang berarti bagimu",
  "Tolong jangan pergi meninggalkanku aku masih sangat mencintai dan menyayangimu",
  "Saya mencintaimu dan menyayangimu jadi tolong jangan engkau pergi dan meninggalkan ku sendiri",
  "Saya sudah cukup tahu bagaimana sifatmu itu kamu hanya dapat memberikan harapan palsu kepadaku",
  "Aku berusaha mendapatkan cinta darimu tetapi Kamunya nggak peka",
  "Aku bangkit dari jatuh ku setelah kau jatuhkan aku dan aku akan memulainya lagi dari awal Tanpamu",
  "Mungkin sekarang jodohku masih jauh dan belum bisa aku dapat tapi aku yakin jodoh itu Takkan kemana-mana dan akan ku dapatkan",
  "Datang aja dulu baru menghina orang lain kalau memang dirimu dan lebih baik dari yang kau hina",
  "Membelakanginya mungkin lebih baik daripada melihatnya selingkuh didepan mata sendiri",
  "Bisakah hatimu seperti angsa yang hanya setia pada satu orang saja",
  "Aku berdiri disini sendiri menunggu kehadiran dirimu",
  "Aku hanya tersenyum padamu setelah kau menyakitiku agar kamu tahu arti kesabaran",
  "Maaf aku lupa ternyata aku bukan siapa-siapa",
  "Untuk memegang janjimu itu harus ada buktinya jangan sampai hanya janji palsu",
  "Aku tidak bisa selamanya menunggu dan kini aku menjadi ragu Apakah kamu masih mencintaiku",
  "Jangan buat aku terlalu berharap jika kamu tidak menginginkanku",
  "Lebih baik sendiri daripada berdua tapi tanpa kepastian",
  "Pergi bukan berarti berhenti mencintai tapi kecewa dan lelah karena harus berjuang sendiri",
  "Bukannya aku tidak ingin menjadi pacarmu Aku hanya ingin dipersatukan dengan cara yang benar",
  "Akan ada saatnya kok aku akan benar-benar lupa dan tidak memikirkan mu lagi",
  "Kenapa harus jatuh cinta kepada orang yang tak bisa dimiliki",
  "Jujur aku juga memiliki perasaan terhadapmu dan tidak bisa menolakmu tapi aku juga takut untuk mencintaimu",
  "Maafkan aku sayang tidak bisa menjadi seperti yang kamu mau",
  "Jangan memberi perhatian lebih seperti itu cukup biasa saja tanpa perlu menimbulkan rasa",
  "Aku bukan mencari yang sempurna tapi yang terbaik untukku",
  "Sendiri itu tenang tidak ada pertengkaran kebohongan dan banyak aturan",
  "Cewek strong itu adalah yang sabar dan tetap tersenyum meskipun dalam keadaan terluka",
  "Terima kasih karena kamu aku menjadi lupa tentang masa laluku",
  "Cerita cinta indah tanpa masalah itu hanya di dunia dongeng saja",
  "Kamu tidak akan menemukan apa-apa di masa lalu Yang ada hanyalah penyesalan dan sakit hati",
  "Mikirin orang yang gak pernah mikirin kita itu emang bikin gila",
  "Dari sekian lama menunggu apa yang sudah didapat",
  "Perasaan Bodo gue adalah bisa jatuh cinta sama orang yang sama meski udah disakiti berkali-kali",
  "Yang sendiri adalah yang bersabar menunggu pasangan sejatinya",
  "Aku terlahir sederhana dan ditinggal sudah biasa",
  "Aku sayang kamu tapi aku masih takut untuk mencintaimu",
  "Bisa berbagi suka dan duka bersamamu itu sudah membuatku bahagia",
  "Aku tidak pernah berpikir kamu akan menjadi yang sementara",
  "Jodoh itu bukan seberapa dekat kamu dengannya tapi seberapa yakin kamu dengan Allah",
  "Jangan paksa aku menjadi cewek seperti seleramu",
  "Hanya yang sabar yang mampu melewati semua kekecewaan",
  "Balikan sama kamu itu sama saja bunuh diri dan melukai perasaan ku sendiri",
  "Tak perlu membalas dengan menyakiti biar Karma yang akan urus semua itu",
  "Aku masih ingat kamu tapi perasaanku sudah tidak sakit seperti dulu",
  "Punya kalimat sendiri & mau ditambahin? chat *.owner*",
];
